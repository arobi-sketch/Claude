import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { HeroVideo } from './components/HeroVideo';
import { RemainderLogo } from './components/RemainderLogo';
import { RiderQuestionnaire } from './components/RiderQuestionnaire';
import { ProductCatalog } from './components/ProductCatalog';
import { ManifestoSection } from './components/ManifestoSection';
import { SignalInterruption } from './components/SignalInterruption';
import { CredibilitySection } from './components/CredibilitySection';
import { Footer } from './components/Footer';
import { ProductModal } from './components/ProductModal';
import { CartDrawer, CartItem } from './components/CartDrawer';
import { Product, PRODUCTS, RidingDiscipline } from './data/products';
import { Sparkles, MapPin, Phone, Mail, ArrowDown } from 'lucide-react';

export default function App() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [inspectedProduct, setInspectedProduct] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeDiscipline, setActiveDiscipline] = useState<RidingDiscipline | 'ALL'>('ALL');
  const [scrollY, setScrollY] = useState<number>(0);
  const [scrollProgress, setScrollProgress] = useState<number>(0);

  // Restrained scroll tracking for gentle, slow hero transitions & scroll progress indicator
  React.useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      setScrollY(currentScrollY);

      const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
      const progress = maxScroll > 0 ? (currentScrollY / maxScroll) * 100 : 0;
      setScrollProgress(Math.min(100, Math.max(0, progress)));
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleAddToCart = (product: Product) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveItem(productId);
      return;
    }
    setCartItems((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveItem = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Item counts per discipline
  const disciplineCounts = useMemo(() => {
    const counts: Record<string, number> = { ALL: PRODUCTS.length };
    ['MTB', 'ROAD', 'GRAVEL', 'BMX', 'CITY', 'E-BIKE'].forEach((d) => {
      counts[d] = PRODUCTS.filter((p) => p.disciplines.includes(d as RidingDiscipline)).length;
    });
    return counts;
  }, []);

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  // Slow and restrained hero motion on scroll
  const heroContentTranslateY = Math.min(scrollY * 0.12, 70);
  const heroContentScale = Math.max(0.985, 1 - scrollY * 0.00004);

  return (
    <div className="relative min-h-screen bg-[#171717] text-[#EAE7DE] overflow-x-hidden selection:bg-[#FF5A00] selection:text-white">
      {/* 
        Atmospheric Mesh Gradient Background with enriched charcoal depth and orange glow
      */}
      <div
        className="fixed inset-0 pointer-events-none z-0 opacity-60"
        style={{
          background: `
            radial-gradient(
              circle at 14% 20%,
              rgba(255, 90, 0, 0.45),
              transparent 42%
            ),
            radial-gradient(
              circle at 82% 75%,
              rgba(35, 35, 38, 0.85),
              transparent 48%
            ),
            #171717
          `,
        }}
      />

      {/* Primary Layout Container */}
      <div className="relative z-10 flex flex-col min-h-screen">
        {/* Top Bar Header with Embedded Sticky Scroll Progress */}
        <Header
          cartCount={totalCartCount}
          onOpenCart={() => setIsCartOpen(true)}
          onSearchClick={() => {
            const el = document.getElementById('archive');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
          scrollProgress={scrollProgress}
        />

        {/* HERO SECTION — Unified Presentation with Video Frame Leading */}
        <section className="relative px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full pt-4 pb-16 sm:pb-24 space-y-6">
          {/* Top Eyebrow Bar */}
          <div className="w-full flex items-center justify-between px-1 text-xs font-mono-spec">
            <div className="inline-flex items-center gap-2 tracking-[0.26em] text-[#FF5A00] uppercase font-bold px-4 py-1.5 rounded-full bg-black/50 border border-white/10 backdrop-blur-md">
              <Sparkles className="w-3.5 h-3.5" />
              <span>CYCLE PARTS RETAILER // SAGARIKA BRANCH, CHITTAGONG</span>
            </div>
            <div className="hidden sm:inline-flex items-center gap-1.5 text-[10px] tracking-widest text-[#EAE7DE]/75 px-3 py-1 rounded-full bg-black/50 border border-white/10 backdrop-blur-md">
              <span className="w-1.5 h-1.5 rounded-full bg-[#FF5A00]" />
              <span>INDEX // {Math.round(scrollProgress)}%</span>
            </div>
          </div>

          {/* 
            THE VIDEO FRAME:
            Sitting in the perfect spot right at the beginning of the hero section.
            Exactly the size of the video (aspect-square), with no sharp edges (rounded-3xl).
          */}
          <div className="flex justify-center w-full pt-2">
            <HeroVideo className="max-w-[480px] sm:max-w-[540px] md:max-w-[580px]" />
          </div>

          {/* Brand Presentation & Editorial Centerpiece */}
          <div
            className="max-w-4xl mx-auto text-center space-y-6 pt-2 will-change-transform"
            style={{
              transform: `translateY(${heroContentTranslateY * 0.3}px) scale(${heroContentScale})`,
            }}
          >
            {/* Pure, Unaltered REMAINDER Brand Logo with Generous Clear Space */}
            <div className="inline-block py-1">
              <RemainderLogo size={84} className="mx-auto drop-shadow-xl" />
            </div>

            <div className="space-y-3">
              <h1 className="font-ariovex text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight text-white leading-[1.04] text-balance">
                THE RESIDUAL FORM OF SPEED
              </h1>

              {/* Requested Manifesto Statement */}
              <p className="font-apoc text-2xl sm:text-3xl md:text-4xl text-white/95 max-w-xl mx-auto leading-relaxed italic font-semibold">
                Go beyond the Basic Ride
              </p>
            </div>

            <p className="text-xs sm:text-sm font-mono-spec text-white/65 max-w-xl mx-auto leading-relaxed">
              Cycle parts retailer and archival component reseller. Precision carbon, mechanical provenance, and secondary perfection at our Sagarika workshop.
            </p>

            {/* Minimal Hero Actions */}
            <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
              <a
                href="#archive"
                className="px-7 py-4 rounded-xl bg-[#FF5A00] text-white hover:bg-white hover:text-[#171717] font-medium text-xs font-mono-spec uppercase tracking-wider transition-all duration-300 shadow-xl cursor-pointer font-bold inline-flex items-center gap-2"
              >
                <span>Explore 8 Component Divisions</span>
                <ArrowDown className="w-3.5 h-3.5" />
              </a>
              <a
                href="#acquisition"
                className="px-7 py-4 rounded-xl bg-black/60 hover:bg-white/20 text-white font-medium text-xs font-mono-spec uppercase tracking-wider transition-all duration-300 border border-white/20 cursor-pointer backdrop-blur-md"
              >
                Sagarika Re-Acquisition
              </a>
            </div>
          </div>

          {/* Quick Location & Direct Contact Strip */}
          <div className="mt-6 p-4 rounded-2xl bg-white/5 border border-white/10 flex flex-wrap items-center justify-between gap-4 text-xs font-mono-spec text-white/75">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#FF5A00]" />
              <span className="font-bold text-white">SAGARIKA BRANCH, 4208, CHITTAGONG</span>
            </div>

            <div className="flex items-center gap-6">
              <a
                href="https://wa.me/8801976912749"
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 text-white hover:text-[#FF5A00] transition-colors"
              >
                <Phone className="w-3.5 h-3.5 text-[#FF5A00]" />
                <span>WHATSAPP: 01976912749</span>
              </a>

              <a
                href="mailto:sifat.01938168@gmail.com"
                className="flex items-center gap-1.5 text-white hover:text-[#FF5A00] transition-colors"
              >
                <Mail className="w-3.5 h-3.5 text-[#FF5A00]" />
                <span>SIFAT.01938168@GMAIL.COM</span>
              </a>
            </div>
          </div>
        </section>

        {/* 
          EDITORIAL PRODUCT EXPERIENCE ORDER:
          Rider Questionnaire → 8 Parts Divisions → Manifesto → Signal-Orange Interruption → Side-by-side Credibility → Refined Footer
        */}
        <main className="space-y-24">
          {/* Question: What do you ride? (MTB | ROAD | GRAVEL | BMX | CITY | E-BIKE) */}
          <RiderQuestionnaire
            activeDiscipline={activeDiscipline}
            onSelectDiscipline={setActiveDiscipline}
            itemCounts={disciplineCounts}
          />

          {/* 8 Component Divisions with real photos and BDT prices */}
          <ProductCatalog
            onInspectProduct={(prod) => setInspectedProduct(prod)}
            onAddToCart={handleAddToCart}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            activeDiscipline={activeDiscipline}
          />

          {/* Manifesto: SAME CYCLE. HIGHER STANDARDS. */}
          <div id="manifesto">
            <ManifestoSection />
          </div>

          {/* Bold Signal-Orange Interruption (The Re-Acquisition Protocol in BDT) */}
          <SignalInterruption />

          {/* Side-by-side Compact Credibility & Testimonial Section */}
          <CredibilitySection />
        </main>

        {/* Refined Footer */}
        <Footer />
      </div>

      {/* Product Inspection Modal */}
      <ProductModal
        product={inspectedProduct}
        onClose={() => setInspectedProduct(null)}
        onAddToCart={handleAddToCart}
      />

      {/* Slide-Over Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />
    </div>
  );
}
