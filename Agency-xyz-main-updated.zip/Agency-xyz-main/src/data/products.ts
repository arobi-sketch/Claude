export type RidingDiscipline = 'MTB' | 'ROAD' | 'GRAVEL' | 'BMX' | 'CITY' | 'E-BIKE';

export interface ProductSpec {
  label: string;
  value: string;
}

export interface Product {
  id: string;
  name: string;
  brand: string;
  section: 'forks' | 'brakes' | 'drivetrain' | 'cranksets' | 'wheels' | 'cassettes' | 'saddles' | 'tools';
  sectionLabel: string;
  priceBDT: number;
  weightGrams: number;
  condition: 'Unridden / Boxed' | 'Atelier Mint' | 'Certified Grade A+' | 'Archival Deadstock';
  serialNumber: string;
  material: string;
  batch: string;
  summary: string;
  provenance: string;
  disciplines: RidingDiscipline[];
  specs: ProductSpec[];
  inStock: boolean;
  imageSrc: string;
  accentBadge?: string;
}

export const PRODUCTS: Product[] = [
  // 1. FORKS
  {
    id: 'fork-rockshox-sid-ultimate',
    name: 'RockShox SID Ultimate Race Day 29" Carbon/Alloy',
    brand: 'RockShox',
    section: 'forks',
    sectionLabel: 'Forks',
    priceBDT: 142000,
    weightGrams: 1480,
    condition: 'Unridden / Boxed',
    serialNumber: 'RS-SID-29-ULT-88',
    material: 'Toray High-Modulus Magnesium / 35mm Fast Black Alloy',
    batch: 'BATCH 04 / SEC 01',
    summary: 'Cross-country racing fork engineered with the ultralight Charger Race Day 2 damper and DebonAir+ air spring. Factory-sealed with zero stanchion friction.',
    provenance: 'Acquired unmounted from WorldTour team reserve stock. Laser-inspected for crown-to-steerer concentricity.',
    disciplines: ['MTB', 'GRAVEL', 'E-BIKE'],
    imageSrc: '/src/assets/images/part_fork_suspension_1790265156967.jpg',
    accentBadge: 'Race Day 2 Damper',
    specs: [
      { label: 'Travel', value: '120 mm' },
      { label: 'Wheel Size', value: '29" Boost (15x110mm)' },
      { label: 'Damper', value: 'Charger Race Day 2 Remote' },
      { label: 'Offset', value: '44 mm' },
      { label: 'Steerer', value: '1.5" Tapered Cut to 210mm' },
      { label: 'Max Rotor', value: '220 mm' }
    ],
    inStock: true
  },
  {
    id: 'fork-fox-34-factory-kashima',
    name: 'Fox 34 Factory Step-Cast FIT4 Kashima 29"',
    brand: 'FOX Racing Shox',
    section: 'forks',
    sectionLabel: 'Forks',
    priceBDT: 156000,
    weightGrams: 1496,
    condition: 'Atelier Mint',
    serialNumber: 'FOX-34-SC-KASH-12',
    material: 'Genuine Kashima Coat Stanchions / Step-Cast Magnesium',
    batch: 'BATCH 04 / SEC 01',
    summary: 'The benchmark lightweight trail/downcountry fork. Featuring FIT4 3-position damper, Kabolt 110 axle, and hollow lower-leg bypass channels.',
    provenance: 'Laboratory dyno-tested on hydraulic suspension dynamometer. Sealed with low-friction SKF wiper seals.',
    disciplines: ['MTB', 'GRAVEL', 'CITY'],
    imageSrc: '/src/assets/images/part_fork_suspension_1790265156967.jpg',
    accentBadge: 'Genuine Kashima',
    specs: [
      { label: 'Travel', value: '120 mm' },
      { label: 'Axle', value: 'Kabolt 15x110mm Boost' },
      { label: 'Coating', value: 'Gold Kashima' },
      { label: 'Damper', value: 'FIT4 3-Position Remote' },
      { label: 'Weight', value: '1,496g verified' },
      { label: 'Air Spring', value: 'Float EVOL' }
    ],
    inStock: true
  },

  // 2. BRAKES
  {
    id: 'brakes-shimano-xtr-m9120',
    name: 'Shimano XTR BR-M9120 4-Piston Hydraulic Disc Set',
    brand: 'Shimano',
    section: 'brakes',
    sectionLabel: 'Brakes',
    priceBDT: 68500,
    weightGrams: 385,
    condition: 'Unridden / Boxed',
    serialNumber: 'SH-XTR-M9120-J04',
    material: 'Mono-body Cold Forged Billet / Ceramic Pistons / Carbon Lever',
    batch: 'BATCH 04 / SEC 02',
    summary: 'Enduro and high-speed braking architecture with Servo Wave leverage and quad-ceramic heat dissipating pistons. Filled with high-boiling mineral oil.',
    provenance: 'Sealed factory packaging with finned Ice-Technologies radiator pads and titanium mounting bolts.',
    disciplines: ['MTB', 'E-BIKE', 'GRAVEL', 'CITY'],
    imageSrc: '/src/assets/images/part_brakes_hydraulic_1790265169447.jpg',
    accentBadge: 'Quad Ceramic Pistons',
    specs: [
      { label: 'Piston Count', value: '4-Piston Ceramic' },
      { label: 'Hose Length', value: 'Front 1000mm / Rear 1700mm' },
      { label: 'Pads', value: 'N04C Metal Finned Radiator' },
      { label: 'Fluid', value: 'Shimano High-Temp Mineral' },
      { label: 'Lever Clamp', value: 'I-SPEC EV Integration' },
      { label: 'Weight', value: '385g (Pair)' }
    ],
    inStock: true
  },
  {
    id: 'brakes-hope-tech4-v4',
    name: 'Hope Tech 4 V4 CNC Billet 4-Piston Caliper System',
    brand: 'Hope Technology',
    section: 'brakes',
    sectionLabel: 'Brakes',
    priceBDT: 74000,
    weightGrams: 310,
    condition: 'Atelier Mint',
    serialNumber: 'HOPE-T4-V4-UK-09',
    material: 'CNC Machined 2014-T6 Aluminum / Stainless Braided Hoses',
    batch: 'BATCH 04 / SEC 02',
    summary: 'Hand-crafted in Barnoldswick, UK. 30% pressure increase over Tech 3, hybrid stainless-ceramic pistons, and tool-free bite point and reach adjustment.',
    provenance: 'Acquired from British bespoke showcase build. Flushed and vacuum-bled with DOT 5.1 fluid.',
    disciplines: ['MTB', 'E-BIKE', 'BMX'],
    imageSrc: '/src/assets/images/part_brakes_hydraulic_1790265169447.jpg',
    accentBadge: 'UK Billet Machined',
    specs: [
      { label: 'Origin', value: 'Barnoldswick, United Kingdom' },
      { label: 'Pistons', value: 'Hybrid Phenolic Stainless' },
      { label: 'Bite Adjust', value: 'Tool-Free Micro-Detent' },
      { label: 'Hose Spec', value: 'Stainless Braided PTFE' },
      { label: 'Mounting', value: 'Post Mount 74mm' },
      { label: 'Finish', value: 'Hard Anodized Stealth Black' }
    ],
    inStock: true
  },

  // 3. GEARS & DRIVETRAIN
  {
    id: 'drivetrain-dura-ace-9250',
    name: 'Shimano Dura-Ace Di2 RD-R9250 12-Speed Derailleur',
    brand: 'Shimano',
    section: 'drivetrain',
    sectionLabel: 'Gears & Drivetrain',
    priceBDT: 89000,
    weightGrams: 215,
    condition: 'Atelier Mint',
    serialNumber: 'SH-DA-RD9250-98',
    material: 'Carbon Fiber Reinforced Polymer / Cold Forged Linkages',
    batch: 'BATCH 04 / SEC 03',
    summary: 'The central hub of 12-speed Shimano electronic shifting. Houses charging port, wireless transmitter, and LED indicator with instantaneous shift actuation.',
    provenance: 'WorldTour test course specimen. Run-tested on diagnostic bench with zero motor backlash.',
    disciplines: ['ROAD', 'GRAVEL', 'CITY'],
    imageSrc: '/src/assets/images/part_drivetrain_derailleur_1790265179513.jpg',
    accentBadge: 'Wireless Di2 Engine',
    specs: [
      { label: 'Speeds', value: '12-Speed Electronic' },
      { label: 'Max Cog', value: '34T Rear Sprocket' },
      { label: 'Connectivity', value: 'Bluetooth LE / ANT+ / Di2' },
      { label: 'Charge Port', value: 'Integrated EW-EC300' },
      { label: 'Total Capacity', value: '37T' },
      { label: 'Weight', value: '215g' }
    ],
    inStock: true
  },
  {
    id: 'drivetrain-sram-xx1-eagle-axs',
    name: 'SRAM XX1 Eagle AXS Wireless Rear Derailleur 52T',
    brand: 'SRAM',
    section: 'drivetrain',
    sectionLabel: 'Gears & Drivetrain',
    priceBDT: 94000,
    weightGrams: 352,
    condition: 'Unridden / Boxed',
    serialNumber: 'SR-XX1-AXS-LUN-77',
    material: 'Carbon Cage / Titanium Spring / Hardened Alloy Pins',
    batch: 'BATCH 04 / SEC 03',
    summary: 'Instantaneous wireless shift response under full 1,000W sprint load. Includes overload gearbox motor clutch to absorb trail impacts without misalignment.',
    provenance: 'Unopened factory service inventory. Pre-paired with AXS firmware 2.41.',
    disciplines: ['MTB', 'GRAVEL', 'E-BIKE'],
    imageSrc: '/src/assets/images/part_drivetrain_derailleur_1790265179513.jpg',
    accentBadge: 'Overload Motor Clutch',
    specs: [
      { label: 'Speeds', value: '12-Speed Wireless' },
      { label: 'Max Sprocket', value: '52T Eagle Cog' },
      { label: 'Clutch', value: 'Type 3 Roller Bearing Clutch' },
      { label: 'Cage Material', value: 'Molded Carbon Fiber' },
      { label: 'Hardware', value: 'Titanium PVD Coated' },
      { label: 'Waterproof', value: 'IP69K High-Pressure Submersion' }
    ],
    inStock: true
  },

  // 4. CRANKSETS
  {
    id: 'crankset-thm-clavicula-se',
    name: 'THM Clavicula SE Full Carbon Crankset 172.5mm',
    brand: 'THM Carbones',
    section: 'cranksets',
    sectionLabel: 'Cranksets',
    priceBDT: 185000,
    weightGrams: 293,
    condition: 'Unridden / Boxed',
    serialNumber: 'THM-SE-1725-GER-41',
    material: 'Continuous Filament Carbon / Integrated 30mm Carbon Axle',
    batch: 'BATCH 04 / SEC 04',
    summary: 'The lightest structural production crankset in cycling history. Both arms and the spindle form a single hollow composite monocoque with zero internal seams.',
    provenance: 'Acquired unridden from a bespoke titanium framebuilder collection in Germany.',
    disciplines: ['ROAD', 'GRAVEL'],
    imageSrc: '/src/assets/images/part_crankset_carbon_1790265196563.jpg',
    accentBadge: 'Sub-300g Benchmark',
    specs: [
      { label: 'Weight', value: '293g (Arms + Axle)' },
      { label: 'Spindle', value: '30mm Integrated Carbon' },
      { label: 'Length', value: '172.5 mm' },
      { label: 'BCD', value: '110mm 4-Bolt Road' },
      { label: 'Max Rider Load', value: '120 kg' },
      { label: 'Finish', value: 'Matte 3K Carbon Weave' }
    ],
    inStock: true
  },
  {
    id: 'crankset-shimano-xtr-m9100',
    name: 'Shimano XTR FC-M9100-1 Hollowtech II MTB Crankset',
    brand: 'Shimano',
    section: 'cranksets',
    sectionLabel: 'Cranksets',
    priceBDT: 54000,
    weightGrams: 511,
    condition: 'Atelier Mint',
    serialNumber: 'SH-XTR-FC9100-32T',
    material: 'Cold-Forged Duralumin Hollow Arms / Direct Mount 32T Chainring',
    batch: 'BATCH 04 / SEC 04',
    summary: 'Unmatched stiffness-to-weight with cold-forged hollow arm construction and Dynamic Chain Engagement+ tooth profiling for flawless retention.',
    provenance: 'Inspected with runout dial gauges. Teeth show zero anodizing wear.',
    disciplines: ['MTB', 'GRAVEL', 'CITY'],
    imageSrc: '/src/assets/images/part_crankset_carbon_1790265196563.jpg',
    accentBadge: 'Hollowtech II Duralumin',
    specs: [
      { label: 'Arm Length', value: '170 mm' },
      { label: 'Chainring', value: '32T Direct Mount CRM95' },
      { label: 'Chainline', value: '52 mm (Boost & Non-Boost)' },
      { label: 'Q-Factor', value: '162 mm' },
      { label: 'BB Interface', value: '24mm Steel Spindle' },
      { label: 'Weight', value: '511g complete' }
    ],
    inStock: true
  },

  // 5. WHEELS & HUBS
  {
    id: 'wheels-dt-swiss-arc-1100',
    name: 'DT Swiss ARC 1100 DICUT Carbon 62mm Mon Chasseral',
    brand: 'DT Swiss',
    section: 'wheels',
    sectionLabel: 'Wheels & Hubs',
    priceBDT: 345000,
    weightGrams: 1380,
    condition: 'Atelier Mint',
    serialNumber: 'DTS-ARC-1100-CH-08',
    material: 'Toray T800 High-Modulus Carbon / SINC Ceramic Bearings',
    batch: 'BATCH 04 / SEC 05',
    summary: 'Aero carbon wheelset equipped with SINC ceramic bearings, 54T Ratchet EXP, and hand-trued spoke tension within 0.05mm radial runout.',
    provenance: 'WorldTour wind-tunnel test specimen. Ultrasonic rim scan verified 100% matrix integrity.',
    disciplines: ['ROAD', 'GRAVEL', 'CITY'],
    imageSrc: '/src/assets/images/part_wheels_carbon_1790265208557.jpg',
    accentBadge: 'SINC Ceramic Bearings',
    specs: [
      { label: 'Profile', value: '62mm Aero Wind-Tunnel' },
      { label: 'Internal Width', value: '20mm Tubeless Ready' },
      { label: 'Hub Type', value: 'DICUT 180 SINC Ceramic' },
      { label: 'Freehub', value: 'Ratchet EXP 54T' },
      { label: 'Brake Interface', value: 'Center Lock Disc' },
      { label: 'Wheelset Weight', value: '1,380g' }
    ],
    inStock: true
  },
  {
    id: 'wheels-chris-king-r45d',
    name: 'Chris King R45D Matte Slate Ceramic Centerlock Hubset',
    brand: 'Chris King Precision Components',
    section: 'wheels',
    sectionLabel: 'Wheels & Hubs',
    priceBDT: 118000,
    weightGrams: 368,
    condition: 'Unridden / Boxed',
    serialNumber: 'CK-R45D-SLATE-19',
    material: 'Aerospace Grade 2024-T6 Aluminum / Surgical Steel-Ceramic Balls',
    batch: 'BATCH 04 / SEC 05',
    summary: 'Portland-engineered precision hubs with the legendary 45-tooth RingDrive instantaneous engagement system and heat-treated stainless steel races.',
    provenance: 'Collector release in rare Matte Slate anodized execution. Lifetime bearing warranty transferable.',
    disciplines: ['ROAD', 'GRAVEL', 'CITY', 'BMX'],
    imageSrc: '/src/assets/images/part_wheels_carbon_1790265208557.jpg',
    accentBadge: 'RingDrive 45T',
    specs: [
      { label: 'Hole Count', value: '24H Front / 24H Rear' },
      { label: 'Axle Standard', value: '12x100mm Front / 12x142mm Rear' },
      { label: 'Engagement', value: '45 Points of Simultaneous Drive' },
      { label: 'Bearings', value: 'Chris King In-House Ceramic' },
      { label: 'Rotor Mount', value: 'Center Lock Spline' },
      { label: 'Made In', value: 'Portland, Oregon, USA' }
    ],
    inStock: true
  },

  // 6. CHAINS & CASSETTES
  {
    id: 'cassette-sram-xx1-rainbow',
    name: 'SRAM XX1 Eagle XG-1299 Rainbow 10-52T + Chain Combo',
    brand: 'SRAM',
    section: 'cassettes',
    sectionLabel: 'Chains & Cassettes',
    priceBDT: 58000,
    weightGrams: 622,
    condition: 'Unridden / Boxed',
    serialNumber: 'SR-XG1299-RB-52',
    material: 'X-Dome CNC Chromoly Steel / 52T Aluminum Cog / Ti-Nitride PVD',
    batch: 'BATCH 04 / SEC 06',
    summary: 'Milled from a single solid billet of tool steel with titanium-nitride rainbow oil-slick treatment. Includes matched XX1 Eagle hollow-pin chain.',
    provenance: 'Factory sealed presentation box. Zero cosmetic or mechanical imperfections.',
    disciplines: ['MTB', 'GRAVEL', 'E-BIKE'],
    imageSrc: '/src/assets/images/part_cassette_rainbow_1790265222090.jpg',
    accentBadge: 'X-Dome Billet Steel',
    specs: [
      { label: 'Range', value: '10-52T (520% Range)' },
      { label: 'Driver Body', value: 'SRAM XD Interface' },
      { label: 'Gear Steps', value: '10,12,14,16,18,21,24,28,32,36,42,52' },
      { label: 'Chain', value: 'XX1 Eagle 126 Links with PowerLock' },
      { label: 'Coating', value: 'PVD Rainbow Titanium Nitride' },
      { label: 'Cassette Weight', value: '372g' }
    ],
    inStock: true
  },
  {
    id: 'cassette-shimano-xtr-cs-m9101',
    name: 'Shimano XTR CS-M9101 12-Speed Cassette 10-51T',
    brand: 'Shimano',
    section: 'cassettes',
    sectionLabel: 'Chains & Cassettes',
    priceBDT: 46500,
    weightGrams: 367,
    condition: 'Atelier Mint',
    serialNumber: 'SH-CS-M9101-1051',
    material: 'Titanium (5 Cogs) + Steel (4 Cogs) + Aluminum (3 Cogs)',
    batch: 'BATCH 04 / SEC 06',
    summary: 'Hyperglide+ tooth architecture enabling shifting both up and down without releasing pedal cadence. Tri-metal composite spider construction.',
    provenance: 'Ultrasonic solvent cleaned and micrometer tooth gauge verified.',
    disciplines: ['MTB', 'GRAVEL', 'E-BIKE', 'CITY'],
    imageSrc: '/src/assets/images/part_cassette_rainbow_1790265222090.jpg',
    accentBadge: 'Hyperglide+ Shift Ramps',
    specs: [
      { label: 'Sprockets', value: '10-51T Wide Range' },
      { label: 'Freehub', value: 'Micro Spline 23-tooth' },
      { label: 'Spider', value: 'Anodized Carbon/Alloy Beam' },
      { label: 'Titanium Cogs', value: 'Cogs 6 through 10' },
      { label: 'Shifting', value: 'Continuous Torque Engagement' },
      { label: 'Weight', value: '367g' }
    ],
    inStock: true
  },

  // 7. SADDLES
  {
    id: 'saddle-specialized-sworks-mirror',
    name: 'Specialized S-Works Power with Mirror Carbon 143mm',
    brand: 'Specialized S-Works',
    section: 'saddles',
    sectionLabel: 'Saddles',
    priceBDT: 56000,
    weightGrams: 190,
    condition: 'Unridden / Boxed',
    serialNumber: 'SP-SW-MIR-143-02',
    material: '3D Printed Liquid Polymer Lattice / FACT Carbon Shell & 7x9 Rails',
    batch: 'BATCH 04 / SEC 07',
    summary: 'Pioneering 3D printed matrix of 22,200 struts and 10,700 nodes that infinitely mirrors sit-bone anatomy to eliminate soft tissue numbness.',
    provenance: 'Unridden inventory from pro fit-studio in Zurich. Factory box with torque guidelines.',
    disciplines: ['ROAD', 'GRAVEL', 'MTB', 'CITY', 'E-BIKE'],
    imageSrc: '/src/assets/images/part_saddle_carbon_1790265238149.jpg',
    accentBadge: '22,200 Liquid Struts',
    specs: [
      { label: 'Width', value: '143 mm' },
      { label: 'Length', value: '240 mm' },
      { label: 'Technology', value: 'Mirror 3D Liquid Polymer' },
      { label: 'Shell', value: 'FACT Full Carbon Fiber' },
      { label: 'Rails', value: '7x9 mm Oversized Carbon' },
      { label: 'Weight', value: '190g' }
    ],
    inStock: true
  },
  {
    id: 'saddle-selle-italia-tekno-superflow',
    name: 'Selle Italia SLR Boost Tekno Superflow Carbon',
    brand: 'Selle Italia × Dallara',
    section: 'saddles',
    sectionLabel: 'Saddles',
    priceBDT: 52000,
    weightGrams: 95,
    condition: 'Atelier Mint',
    serialNumber: 'SI-DAL-TK-S3-18',
    material: '100% Autoclave Prepreg Carbon Monocoque / CarboKeramic Rails',
    batch: 'BATCH 04 / SEC 07',
    summary: 'Engineered in Dallara racing automotive autoclaves. Structural carbon monocoque shell tipping the scales at an astonishing sub-100g figure.',
    provenance: 'Archival release, preserved in original graphite presentation sleeve.',
    disciplines: ['ROAD', 'GRAVEL'],
    imageSrc: '/src/assets/images/part_saddle_carbon_1790265238149.jpg',
    accentBadge: 'Dallara Autoclave Mold',
    specs: [
      { label: 'Dimensions', value: '130 × 248 mm (S3)' },
      { label: 'Weight', value: '95g verified' },
      { label: 'Rails', value: 'CarboKeramic 7x9 mm' },
      { label: 'Channel', value: 'Superflow Anatomic Cutout' },
      { label: 'Rider Max', value: '90 kg' },
      { label: 'Origin', value: 'Asolo, Italy' }
    ],
    inStock: true
  },

  // 8. TOOLS & ACCESSORIES
  {
    id: 'tools-silca-tratchet-titorque',
    name: 'Silca T-Ratchet + Ti-Torque Titanium Precision Kit',
    brand: 'Silca',
    section: 'tools',
    sectionLabel: 'Tools & Accessories',
    priceBDT: 32500,
    weightGrams: 410,
    condition: 'Unridden / Boxed',
    serialNumber: 'SIL-TR-TIT-24-06',
    material: 'CNC 7075 Aluminum Handle / Titanium Torque Beam / S2 Hardened Steel Bits',
    batch: 'BATCH 04 / SEC 08',
    summary: 'Precision torque-limiting bit driver engineered in Indianapolis. Live torque-reading beam calibrated for carbon assembly work, from 2 to 24 Nm across fourteen hardened bits.',
    provenance: "Sourced directly from Silca's Indianapolis workshop reserve. Beam calibration verified against reference torque cell.",
    disciplines: ['MTB', 'ROAD', 'GRAVEL', 'BMX', 'CITY', 'E-BIKE'],
    imageSrc: '/src/assets/images/tool_torque_precision_kit.svg',
    accentBadge: 'Live-Read Ti Beam',
    specs: [
      { label: 'Torque Range', value: '2-24 Nm Live Read' },
      { label: 'Bit Count', value: '14 Hardened S2 Bits' },
      { label: 'Beam Material', value: 'Aerospace Titanium' },
      { label: 'Handle', value: 'Knurled 7075 Aluminum' },
      { label: 'Case', value: 'Molded EVA Travel Case' },
      { label: 'Weight', value: '410g complete kit' }
    ],
    inStock: true
  },
  {
    id: 'tools-park-prs22-stand',
    name: 'Park Tool PRS-22.2 Team Issue Repair Stand',
    brand: 'Park Tool',
    section: 'tools',
    sectionLabel: 'Tools & Accessories',
    priceBDT: 48000,
    weightGrams: 9200,
    condition: 'Atelier Mint',
    serialNumber: 'PARK-PRS222-TI-31',
    material: 'Powder-Coated Steel Tripod / Micro-Adjust Clamp Alloy Jaws',
    batch: 'BATCH 04 / SEC 08',
    summary: 'Professional-grade telescoping workshop stand with the 100-3D micro-adjust clamp. Engineered for repeated atelier assembly and torque-verification work.',
    provenance: 'Retired from a certified WorldTour team mechanic truck. Full clamp and telescoping function inspected.',
    disciplines: ['MTB', 'ROAD', 'GRAVEL', 'BMX', 'CITY', 'E-BIKE'],
    imageSrc: '/src/assets/images/tool_repair_stand.svg',
    accentBadge: '100-3D Micro-Adjust Clamp',
    specs: [
      { label: 'Clamp', value: 'Park Tool 100-3D Micro-Adjust' },
      { label: 'Clamping Range', value: 'Up to 2-inch Tube Diameter' },
      { label: 'Base', value: 'Telescoping Tripod, Rubber Feet' },
      { label: 'Max Load', value: '36 kg (80 lb)' },
      { label: 'Height', value: 'Adjustable 122-185 cm' },
      { label: 'Weight', value: '9.2 kg stand' }
    ],
    inStock: true
  }
];

export const SECTIONS = [
  { id: 'all', label: 'All Categories' },
  { id: 'forks', label: 'Forks' },
  { id: 'brakes', label: 'Brakes' },
  { id: 'drivetrain', label: 'Gears & Drivetrain' },
  { id: 'cranksets', label: 'Cranksets' },
  { id: 'wheels', label: 'Wheels & Hubs' },
  { id: 'cassettes', label: 'Chains & Cassettes' },
  { id: 'saddles', label: 'Saddles' },
  { id: 'tools', label: 'Tools & Accessories' }
] as const;

export const DISCIPLINES: { id: RidingDiscipline | 'ALL'; label: string; desc: string }[] = [
  { id: 'ALL', label: 'ALL DISCIPLINES', desc: 'Browse full curated register' },
  { id: 'MTB', label: 'MTB', desc: 'Downcountry, Trail & Enduro' },
  { id: 'ROAD', label: 'ROAD', desc: 'Aero, Lightweight & Criterion' },
  { id: 'GRAVEL', label: 'GRAVEL', desc: 'All-Road & Bikepacking' },
  { id: 'BMX', label: 'BMX', desc: 'Street, Race & Flatland' },
  { id: 'CITY', label: 'CITY', desc: 'Urban & Commuter Builds' },
  { id: 'E-BIKE', label: 'E-BIKE', desc: 'High-Torque Certified' },
];
