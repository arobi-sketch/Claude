import React, { useState } from 'react';
import { ShieldCheck, ChevronLeft, ChevronRight, Quote } from 'lucide-react';

interface Testimonial {
  quote: string;
  author: string;
  role: string;
  organization: string;
  location: string;
  testedSpecimen: string;
  valuationBDT: string;
}

const TESTIMONIALS: Testimonial[] = [
  {
    quote: "REMAINDER is the only archival reseller where every THM crank and Darimo bar comes with verifiable ultrasonic certification. Uncompromising standards.",
    author: "Matthias Vane",
    role: "Master Framebuilder",
    organization: "Vane Atelier",
    location: "Berlin / Chittagong Dispatch",
    testedSpecimen: "THM Clavicula SE #0418",
    valuationBDT: "৳185,000",
  },
  {
    quote: "Finding unridden WorldTour reserve components—like custom-caged Dura-Ace Di2 and pristine ceramic pulleys—without risking counterfeit carbon was virtually impossible before REMAINDER.",
    author: "Elena Rostova",
    role: "Lead Mechanic",
    organization: "Girona Service Course",
    location: "Girona / Sagarika Transit",
    testedSpecimen: "Shimano Dura-Ace Di2 9250",
    valuationBDT: "৳89,000",
  },
  {
    quote: "The delivery arrived at our Sagarika workshop in sealed graphite cases. The 74g Extralite stem was identical to factory tolerance. Pure architectural care.",
    author: "Julian Koster",
    role: "Bespoke Collector & Randonneur",
    organization: "Atelier Zurich",
    location: "Chittagong Hub",
    testedSpecimen: "DT Swiss ARC 1100 62mm",
    valuationBDT: "৳345,000",
  },
];

export const CredibilitySection: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const prev = () => setCurrentIndex((i) => (i === 0 ? TESTIMONIALS.length - 1 : i - 1));
  const next = () => setCurrentIndex((i) => (i === TESTIMONIALS.length - 1 ? 0 : i + 1));

  return (
    <section id="provenance" className="py-12 sm:py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-[#171717]">
      {/* Compact Side-By-Side Layout (Consuming minimal vertical space) */}
      <div className="rounded-2xl bg-[#171717] text-[#EAE7DE] border border-white/15 p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        {/* Subtle Orange Glow */}
        <div className="absolute top-1/2 -left-20 -translate-y-1/2 w-64 h-64 bg-[#FF5A00]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* Left Column: Heading & Controls */}
          <div className="lg:col-span-4 space-y-3 pr-4 border-b lg:border-b-0 lg:border-r border-white/10 pb-4 lg:pb-0">
            <div className="inline-flex items-center gap-2 text-[10px] font-mono-spec tracking-widest text-[#FF5A00] uppercase font-bold">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>TESTED PROVENANCE</span>
            </div>

            <h3 className="font-ariovex text-xl sm:text-2xl font-bold tracking-tight text-white leading-tight">
              VERIFIED ATELIER REVIEWS
            </h3>

            <p className="font-apoc text-xs sm:text-sm text-white/70 leading-relaxed">
              Every certified specimen is audited across ultrasonic tomography before clearance through our Sagarika branch.
            </p>

            {/* Pagination Controls */}
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={prev}
                className="p-1.5 rounded-lg bg-white/10 hover:bg-[#FF5A00] text-white transition-colors cursor-pointer"
                aria-label="Previous review"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="text-xs font-mono-spec text-white/50 px-2">
                0{currentIndex + 1} / 0{TESTIMONIALS.length}
              </span>
              <button
                onClick={next}
                className="p-1.5 rounded-lg bg-white/10 hover:bg-[#FF5A00] text-white transition-colors cursor-pointer"
                aria-label="Next review"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Right Column: Side-by-Side Scrolling Review Cards (Compact) */}
          <div className="lg:col-span-8">
            <div className="relative p-5 sm:p-6 rounded-xl bg-white/5 border border-white/10 flex flex-col justify-between min-h-[160px]">
              <Quote className="w-8 h-8 text-[#FF5A00]/30 absolute top-4 right-4 pointer-events-none" />

              <p className="font-apoc text-base sm:text-lg text-white leading-relaxed italic pr-8 mb-4">
                "{TESTIMONIALS[currentIndex].quote}"
              </p>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-white/10 text-xs font-mono-spec">
                <div>
                  <span className="font-bold text-[#EAE7DE]">{TESTIMONIALS[currentIndex].author}</span>
                  <span className="text-white/40 mx-2">·</span>
                  <span className="text-white/70">{TESTIMONIALS[currentIndex].role}, {TESTIMONIALS[currentIndex].organization}</span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-white/50 uppercase">{TESTIMONIALS[currentIndex].testedSpecimen}</span>
                  <span className="px-2 py-0.5 rounded bg-[#FF5A00] text-white font-bold text-[10px]">
                    {TESTIMONIALS[currentIndex].valuationBDT}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CredibilitySection;
