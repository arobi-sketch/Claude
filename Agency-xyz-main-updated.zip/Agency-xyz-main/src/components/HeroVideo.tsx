import React, { useRef, useState, useEffect } from 'react';
import { Volume2, VolumeX } from 'lucide-react';

interface HeroVideoProps {
  className?: string;
}

export const HeroVideo: React.FC<HeroVideoProps> = ({ className = '' }) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [isMuted, setIsMuted] = useState<boolean>(true);

  // Always-on background video: no play/pause control is exposed to the
  // visitor, so playback should never stop. Muted autoplay is reliably
  // allowed by every major browser, and if anything ever pauses the
  // element (tab restore, a stray event, etc.) we immediately resume it
  // so the loop never visibly interrupts.
  useEffect(() => {
    const vid = videoRef.current;
    if (!vid) return;

    const resume = () => {
      vid.play().catch(() => {
        /* Autoplay can only be blocked without a muted element; muted
           playback is exempt from that restriction in every major browser. */
      });
    };

    resume();

    vid.addEventListener('pause', resume);
    vid.addEventListener('ended', resume);
    document.addEventListener('visibilitychange', resume);

    return () => {
      vid.removeEventListener('pause', resume);
      vid.removeEventListener('ended', resume);
      document.removeEventListener('visibilitychange', resume);
    };
  }, []);

  const toggleSound = () => {
    const vid = videoRef.current;
    if (!vid) return;
    vid.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  return (
    <div
      className={`group relative aspect-square w-full rounded-3xl overflow-hidden border border-white/20 bg-black shadow-2xl flex items-center justify-center select-none ${className}`}
      style={{ borderRadius: '1.75rem' }}
    >
      {/* Video filling the exact square frame with no sharp edges. Always
          playing, always looping — no play/pause control exists for it. */}
      <video
        ref={videoRef}
        autoPlay
        muted={isMuted}
        loop
        playsInline
        disablePictureInPicture
        controls={false}
        preload="auto"
        className="w-full h-full object-cover select-none pointer-events-none"
        style={{ borderRadius: '1.75rem' }}
      >
        <source src="/hero-video.mp4" type="video/mp4" />
        <source
          src="/Had some fun creating a little sting for the guys at _statebicycleco _Loved building the sequence_ from modelling the bike to creating the scenes_ through t(.mp4"
          type="video/mp4"
        />
        Your browser does not support the video tag.
      </video>

      {/* Frame Specular Ring with no sharp edges */}
      <div
        className="absolute inset-0 pointer-events-none border border-white/15 transition-colors group-hover:border-[#FF5A00]/40"
        style={{ borderRadius: '1.75rem' }}
      />

      {/* Sound Toggle — the only playback-adjacent control left. Muting
          never pauses the loop, it only affects audio. */}
      <div className="absolute bottom-4 right-4 z-30 flex items-center gap-2 pointer-events-auto">
        <button
          type="button"
          onClick={toggleSound}
          className="px-3 py-2 rounded-xl bg-black/70 hover:bg-black/90 border border-white/20 text-white hover:text-[#FF5A00] transition-all text-[11px] font-mono-spec flex items-center gap-1.5 cursor-pointer backdrop-blur-md shadow-lg"
          title={isMuted ? 'Unmute video' : 'Mute video'}
          aria-label={isMuted ? 'Unmute' : 'Mute'}
        >
          {isMuted ? (
            <VolumeX className="w-4 h-4 text-white/70" />
          ) : (
            <Volume2 className="w-4 h-4 text-[#FF5A00]" />
          )}
          <span className="hidden sm:inline font-bold">
            {isMuted ? 'SOUND OFF' : 'SOUND ON'}
          </span>
        </button>
      </div>
    </div>
  );
};

export default HeroVideo;
