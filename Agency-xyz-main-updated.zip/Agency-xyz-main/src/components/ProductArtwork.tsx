import React from 'react';

interface ProductArtworkProps {
  type: 'wheel' | 'crank' | 'pulley' | 'cockpit' | 'stem' | 'saddle' | 'derailleur' | 'rotor';
  className?: string;
  isHovered?: boolean;
}

export const ProductArtwork: React.FC<ProductArtworkProps> = ({
  type,
  className = '',
  isHovered = false,
}) => {
  const graphite = '#171717';
  const orange = '#FF5A00';
  const bone = '#EAE7DE';

  return (
    <div
      className={`relative w-full h-full flex items-center justify-center overflow-hidden transition-transform duration-500 ${
        isHovered ? 'scale-[1.03]' : 'scale-100'
      } ${className}`}
    >
      {/* Restrained liquid-glass backdrop with subtle warm refraction */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#171717]/[0.03] to-[#171717]/[0.07] pointer-events-none" />

      {/* Glossy top specular reflection line */}
      <div className="absolute top-0 left-0 right-0 h-1/3 bg-gradient-to-b from-white/30 to-transparent pointer-events-none" />

      {/* Type-specific Architectural Graphic */}
      <svg
        viewBox="0 0 400 320"
        className="w-full h-full max-h-64 select-none drop-shadow-lg"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {type === 'wheel' && (
          <g transform="translate(200, 160)">
            {/* Deep Section Carbon Rim Profile (62mm) */}
            <circle r="130" stroke={graphite} strokeWidth="18" className="opacity-95" />
            <circle r="121" stroke="#2a2a2a" strokeWidth="2" strokeDasharray="4 4" />
            {/* Rim Bead Internal Channel */}
            <circle r="139" stroke={bone} strokeWidth="1.5" />
            
            {/* Signal Orange Decal Accent Bar */}
            <path
              d="M -130 0 A 130 130 0 0 1 -115 -60"
              stroke={orange}
              strokeWidth="18"
              strokeLinecap="round"
            />

            {/* Aerolite Spoke Pattern */}
            {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((deg, i) => (
              <line
                key={i}
                x1={Math.cos((deg * Math.PI) / 180) * 24}
                y1={Math.sin((deg * Math.PI) / 180) * 24}
                x2={Math.cos(((deg + 15) * Math.PI) / 180) * 121}
                y2={Math.sin(((deg + 15) * Math.PI) / 180) * 121}
                stroke={graphite}
                strokeWidth="1.8"
                opacity="0.55"
              />
            ))}

            {/* SINC Ceramic Central Hub & Ratchet Shell */}
            <circle r="26" fill={graphite} />
            <circle r="18" stroke={bone} strokeWidth="1.5" />
            <circle r="9" fill={orange} />
            <circle r="4" fill="#FFFFFF" />

            {/* Technical Dimension Markings */}
            <text
              x="0"
              y="95"
              textAnchor="middle"
              fill={graphite}
              className="text-[9px] font-mono-spec tracking-widest font-semibold"
            >
              62MM MON CHASSERAL · 1380G
            </text>
          </g>
        )}

        {type === 'crank' && (
          <g transform="translate(200, 160)">
            {/* Hollow Carbon Crankarm (THM Clavicula SE) */}
            <path
              d="M -120 18 C -135 18 -145 5 -145 -10 C -145 -25 -135 -38 -120 -38 L 85 -24 C 115 -24 135 -5 135 20 C 135 45 115 62 85 62 L -120 18 Z"
              fill={graphite}
              stroke="#2e2e30"
              strokeWidth="2"
            />
            {/* 3K Carbon Weave Specular Glaze */}
            <path
              d="M -110 -25 L 75 -15 C 95 -15 115 -2 115 18"
              stroke="rgba(255,255,255,0.3)"
              strokeWidth="2.5"
              strokeLinecap="round"
            />

            {/* Pedal Eyelet Titanium Insert */}
            <circle cx="-120" cy="-10" r="16" fill={bone} stroke={graphite} strokeWidth="3" />
            <circle cx="-120" cy="-10" r="9" fill={graphite} />

            {/* 30mm Integrated Carbon Spindle Bore */}
            <circle cx="95" cy="20" r="32" fill="#202022" stroke={bone} strokeWidth="2" />
            <circle cx="95" cy="20" r="22" stroke={orange} strokeWidth="3" />
            <circle cx="95" cy="20" r="12" fill={graphite} />

            {/* Signal Orange Atelier Stamp */}
            <rect x="-35" y="-12" width="40" height="7" rx="1" fill={orange} />
            <text
              x="-15"
              y="-6.5"
              textAnchor="middle"
              fill="#FFFFFF"
              className="text-[6px] font-mono-spec font-bold"
            >
              THM · 293G
            </text>
          </g>
        )}

        {type === 'pulley' && (
          <g transform="translate(200, 160)">
            {/* CeramicSpeed Aero Carbon Outer Cage Shell */}
            <path
              d="M -30 -80 C 15 -85 70 -55 75 -15 C 80 25 70 85 20 100 C -15 105 -50 80 -60 40 C -70 -10 -55 -75 -30 -80 Z"
              fill={graphite}
              stroke="#2d2d30"
              strokeWidth="2"
            />
            {/* Aero Blade Rib Cutouts */}
            <path
              d="M -10 -45 L 35 -30 C 45 -10 40 30 5 45 L -25 35"
              stroke={bone}
              strokeWidth="1.5"
              strokeDasharray="3 3"
              fill="none"
            />

            {/* Upper 13T Pulley Wheel */}
            <circle cx="0" cy="-45" r="24" stroke={graphite} strokeWidth="3" fill="#262628" />
            <circle cx="0" cy="-45" r="10" fill={orange} />
            <circle cx="0" cy="-45" r="4" fill="#FFFFFF" />

            {/* Lower 19T Oversized Pulley Wheel */}
            <circle cx="10" cy="55" r="36" stroke={graphite} strokeWidth="4" fill="#262628" />
            <circle cx="10" cy="55" r="14" fill={orange} />
            <circle cx="10" cy="55" r="6" fill="#FFFFFF" />

            {/* Carbon Cage Edge Highlight */}
            <path
              d="M 68 -20 C 72 20 62 70 20 88"
              stroke="rgba(255,255,255,0.4)"
              strokeWidth="2"
              strokeLinecap="round"
            />
          </g>
        )}

        {type === 'cockpit' && (
          <g transform="translate(200, 160)">
            {/* One-Piece Handcrafted Carbon Bar (Darimo Nexum) */}
            {/* Stem Section */}
            <polygon points="-30,-75 30,-75 22,10 -22,10" fill={graphite} />
            <circle cx="0" cy="-60" r="16" stroke={bone} strokeWidth="2" fill="#202022" />
            <line x1="0" y1="-75" x2="0" y2="-45" stroke={orange} strokeWidth="2" />

            {/* Integrated Top Bar Wing Profile */}
            <path
              d="M -155 10 C -110 5 -50 8 0 10 C 50 8 110 5 155 10 C 168 12 175 22 172 38 L 160 85 C 158 95 146 100 138 92 L 130 82 C 138 60 142 45 135 34 C 110 28 60 26 0 26 C -60 26 -110 28 -135 34 C -142 45 -138 60 -130 82 L -138 92 C -146 100 -158 95 -160 85 L -172 38 C -175 22 -168 12 -155 10 Z"
              fill={graphite}
              stroke="#2e2e30"
              strokeWidth="2"
            />

            {/* Signal Orange Dyneema Clamping Accents */}
            <rect x="-24" y="-72" width="48" height="4" fill={orange} rx="1" />
            <circle cx="-135" cy="34" r="3" fill={orange} />
            <circle cx="135" cy="34" r="3" fill={orange} />

            <text
              x="0"
              y="60"
              textAnchor="middle"
              fill={bone}
              className="text-[8px] font-mono-spec tracking-widest opacity-80"
            >
              DARIMO · 195G ULTRA-HIGH MODULUS
            </text>
          </g>
        )}

        {type === 'stem' && (
          <g transform="translate(200, 160)">
            {/* CNC 7075 Billet Stem Body (Extralite HyperStem) */}
            <polygon
              points="-105,-28 85,-44 110,-24 110,24 85,44 -105,28"
              fill={graphite}
              stroke="#343438"
              strokeWidth="2"
            />
            {/* Lightening Windows / CNC Chamfers */}
            <polygon points="-65,-14 60,-24 60,-8 -65,-4" fill="#232326" stroke={bone} strokeWidth="1" />
            <polygon points="-65,4 60,8 60,24 -65,14" fill="#232326" stroke={bone} strokeWidth="1" />

            {/* Steerer Clamp Rear */}
            <circle cx="-95" cy="0" r="26" stroke={bone} strokeWidth="2" fill="#1b1b1d" />
            <circle cx="-95" cy="0" r="14" fill={graphite} />
            {/* Torx Titanium Bolts */}
            <circle cx="-75" cy="-22" r="3.5" fill={orange} />
            <circle cx="-75" cy="22" r="3.5" fill={orange} />

            {/* Handlebar Faceplate Clamping */}
            <rect x="92" y="-38" width="14" height="76" rx="2" fill="#242426" stroke={bone} strokeWidth="1.5" />
            <circle cx="99" cy="-24" r="3" fill={orange} />
            <circle cx="99" cy="-8" r="3" fill={orange} />
            <circle cx="99" cy="8" r="3" fill={orange} />
            <circle cx="99" cy="24" r="3" fill={orange} />
          </g>
        )}

        {type === 'saddle' && (
          <g transform="translate(200, 160)">
            {/* Selle Italia SLR Boost Tekno Dallara Monocoque */}
            {/* CarboKeramic 7x9 Rails */}
            <path
              d="M -70 24 L -10 24 L 60 14 M -70 32 L -10 32 L 60 22"
              stroke={graphite}
              strokeWidth="4"
              strokeLinecap="round"
            />
            <path
              d="M -10 24 L 20 5 M -10 32 L 20 10"
              stroke={orange}
              strokeWidth="3"
            />

            {/* Carbon Shell Upper Wing Profile */}
            <path
              d="M -115 -25 C -75 -40 25 -42 110 -15 C 130 -9 135 8 115 15 C 50 32 -60 30 -115 5 C -130 -2 -130 -18 -115 -25 Z"
              fill={graphite}
              stroke="#2e2e30"
              strokeWidth="2"
            />

            {/* Superflow Central Anatomic Relief Cutout */}
            <ellipse cx="10" cy="-6" rx="42" ry="9" fill={bone} />
            <ellipse cx="10" cy="-6" rx="38" ry="6" fill="#1b1b1d" />

            {/* Dallara Aerodynamic Logo line */}
            <path
              d="M 85 -10 L 115 -4"
              stroke={orange}
              strokeWidth="2.5"
              strokeLinecap="round"
            />
          </g>
        )}

        {type === 'derailleur' && (
          <g transform="translate(200, 160)">
            {/* Custom Hand-Brushed Dura-Ace Di2 Housing */}
            <polygon
              points="-60,-45 40,-60 65,-10 20,40 -40,30"
              fill="#2e2e32"
              stroke={bone}
              strokeWidth="2"
            />
            {/* Metallic Satin Brush Marks */}
            <line x1="-40" y1="-30" x2="35" y2="-42" stroke="rgba(255,255,255,0.4)" strokeWidth="2" />
            <line x1="-30" y1="-10" x2="45" y2="-20" stroke="rgba(255,255,255,0.3)" strokeWidth="1.5" />

            {/* Carbon Lower Cage Arm */}
            <polygon points="-10,20 15,90 -10,85 -30,25" fill={graphite} />
            {/* Pulleys */}
            <circle cx="15" cy="90" r="14" stroke={graphite} strokeWidth="3" fill="#202022" />
            <circle cx="15" cy="90" r="5" fill={orange} />
            <circle cx="-25" cy="20" r="14" stroke={graphite} strokeWidth="3" fill="#202022" />
            <circle cx="-25" cy="20" r="5" fill={orange} />

            {/* Titanium Pivot Pin */}
            <circle cx="-15" cy="-25" r="10" fill={orange} />
            <circle cx="-15" cy="-25" r="4" fill="#FFFFFF" />
          </g>
        )}

        {type === 'rotor' && (
          <g transform="translate(200, 160)">
            {/* Carbon-Ti X-Rotor Floating Disc */}
            {/* Outer Martensitic Steel Braking Track */}
            <circle r="120" stroke={graphite} strokeWidth="22" className="opacity-95" />
            {/* Heat Dissipation Wave Cutouts */}
            {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((deg, i) => (
              <circle
                key={i}
                cx={Math.cos((deg * Math.PI) / 180) * 120}
                cy={Math.sin((deg * Math.PI) / 180) * 120}
                r="4.5"
                fill={bone}
              />
            ))}

            {/* Laser-Cut Structural Carbon Central Spider */}
            {[0, 60, 120, 180, 240, 300].map((deg, i) => {
              const rad = (deg * Math.PI) / 180;
              const x1 = Math.cos(rad) * 45;
              const y1 = Math.sin(rad) * 45;
              const x2 = Math.cos(rad) * 105;
              const y2 = Math.sin(rad) * 105;
              return (
                <g key={i}>
                  <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="#222225" strokeWidth="12" />
                  {/* Grade 5 Titanium Floating Rivets */}
                  <circle cx={x2} cy={y2} r="5.5" fill={orange} stroke={bone} strokeWidth="1" />
                </g>
              );
            })}

            {/* Hub Carrier Base */}
            <circle r="46" fill={graphite} stroke={bone} strokeWidth="2" />
            <circle r="32" stroke={bone} strokeWidth="1.5" strokeDasharray="4 4" />
            {/* Center Lock / 6-Bolt holes */}
            {[0, 60, 120, 180, 240, 300].map((deg, i) => (
              <circle
                key={i}
                cx={Math.cos((deg * Math.PI) / 180) * 32}
                cy={Math.sin((deg * Math.PI) / 180) * 32}
                r="3"
                fill={bone}
              />
            ))}
            <circle r="18" fill="#121214" />
          </g>
        )}
      </svg>
    </div>
  );
};

export default ProductArtwork;
