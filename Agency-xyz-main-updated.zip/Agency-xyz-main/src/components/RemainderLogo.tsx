import React from 'react';

interface RemainderLogoProps {
  className?: string;
  size?: number | string;
  variant?: 'solid' | 'transparent' | 'inverted';
}

export const RemainderLogo: React.FC<RemainderLogoProps> = ({
  className = '',
  size = 48,
}) => {
  const widthVal = typeof size === 'number' ? `${size}px` : size;

  return (
    <img
      src="/remainder-brand.png"
      alt="REMAINDER"
      className={`select-none object-contain block shrink-0 ${className}`}
      style={{
        width: widthVal,
        height: 'auto',
        aspectRatio: '459 / 499',
      }}
      loading="eager"
      decoding="async"
    />
  );
};

export default RemainderLogo;
