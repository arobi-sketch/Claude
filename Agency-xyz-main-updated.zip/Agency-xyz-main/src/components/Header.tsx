import React, { useState } from 'react';
import { ShoppingBag, Search, Menu, X, Phone } from 'lucide-react';
import { RemainderLogo } from './RemainderLogo';

interface HeaderProps {
  cartCount: number;
  onOpenCart: () => void;
  onSearchClick: () => void;
  scrollProgress?: number;
}

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  onOpenCart,
  onSearchClick,
  scrollProgress = 0,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full transition-all duration-300 bg-[#171717]/95 text-[#EAE7DE] border-b border-white/10 shadow-xl backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4 relative">
        {/* Zone 1: Pure Brand Logo & Wordmark without any deformation */}
        <a
          href="#"
          className="flex items-center gap-3.5 group focus-visible:outline-none"
          aria-label="REMAINDER Home"
        >
          <RemainderLogo size={36} className="transition-transform group-hover:scale-105" />
          <span className="font-ariovex text-base sm:text-lg font-extrabold tracking-[0.22em] text-[#EAE7DE] select-none">
            REMAINDER
          </span>
        </a>

        {/* Zone 2: Curated Nav Links (Strict Top Bar Contract) */}
        <nav className="hidden lg:flex items-center gap-8 text-xs font-mono-spec tracking-wider text-white/80">
          <a
            href="#archive"
            className="hover:text-[#FF5A00] transition-colors uppercase"
          >
            8 Divisions
          </a>
          <a
            href="#manifesto"
            className="hover:text-[#FF5A00] transition-colors uppercase"
          >
            Manifesto
          </a>
          <a
            href="#acquisition"
            className="hover:text-[#FF5A00] transition-colors uppercase"
          >
            Re-Acquisition
          </a>
          <a
            href="#provenance"
            className="hover:text-[#FF5A00] transition-colors uppercase"
          >
            Provenance
          </a>
        </nav>

        {/* Zone 3: Actions & Currency indicator (BDT) */}
        <div className="flex items-center gap-3 sm:gap-4">
          {/* Quick Currency readout */}
          <span className="hidden sm:inline-block text-[11px] font-mono-spec text-white/50 bg-white/5 px-2 py-1 rounded border border-white/10">
            BDT (৳)
          </span>

          {/* Direct WhatsApp Callout */}
          <a
            href="https://wa.me/8801976912749"
            target="_blank"
            rel="noreferrer"
            className="hidden sm:flex items-center gap-1.5 text-xs font-mono-spec text-white/80 hover:text-[#FF5A00] transition-colors"
            title="WhatsApp 01976912749"
          >
            <Phone className="w-3.5 h-3.5 text-[#FF5A00]" />
            <span className="text-[11px]">01976912749</span>
          </a>

          {/* Quick Search */}
          <button
            onClick={onSearchClick}
            className="p-2 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Search archive"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Cart Bag */}
          <button
            onClick={onOpenCart}
            className="relative px-3.5 py-2 rounded-xl bg-[#FF5A00] text-white hover:bg-white hover:text-[#171717] transition-all flex items-center gap-2 text-xs font-mono-spec font-bold cursor-pointer whitespace-nowrap shadow-md"
            aria-label={`Cart with ${cartCount} items`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">BAG</span>
            <span className="w-5 h-5 rounded-full bg-[#171717] text-white text-[10px] font-bold flex items-center justify-center">
              {cartCount}
            </span>
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg text-white hover:bg-white/10 cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* 
        STICKY SCROLL PROGRESS BAR:
        Always remains with the header at the top of the viewport during entire scroll 
      */}
      <div
        className="absolute bottom-0 left-0 right-0 h-[2.5px] bg-white/10 overflow-hidden pointer-events-none"
        role="progressbar"
        aria-valuenow={Math.round(scrollProgress)}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label="Page scroll progress"
      >
        <div
          className="h-full bg-[#FF5A00] transition-[width] duration-100 ease-out will-change-[width] shadow-[0_0_10px_rgba(255,90,0,0.9)]"
          style={{ width: `${Math.min(100, Math.max(0, scrollProgress))}%` }}
        />
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-white/10 bg-[#171717] px-6 py-6 space-y-4 font-mono-spec text-xs text-white">
          <a
            href="#archive"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 uppercase hover:text-[#FF5A00]"
          >
            8 Component Divisions
          </a>
          <a
            href="#manifesto"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 uppercase hover:text-[#FF5A00]"
          >
            Manifesto: Same Cycle. Higher Standards.
          </a>
          <a
            href="#acquisition"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 uppercase text-[#FF5A00] font-bold"
          >
            Re-Acquisition: Sagarika Branch
          </a>
          <a
            href="#provenance"
            onClick={() => setMobileMenuOpen(false)}
            className="block py-2 uppercase hover:text-[#FF5A00]"
          >
            Provenance & Reviews
          </a>
          <div className="pt-4 border-t border-white/10 space-y-2 text-xs text-white/70">
            <p>LOCATION: SAGARIKA BRANCH, 4208, CHITTAGONG</p>
            <p>WHATSAPP: 01976912749</p>
            <p>EMAIL: SIFAT.01938168@GMAIL.COM</p>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
