import React from 'react';
import { Layers, ShieldAlert, Cpu, ArrowUpRight } from 'lucide-react';

export const EditorialSection: React.FC = () => {
  return (
    <section className="py-24 sm:py-32 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-[#EAE7DE]">
      {/* Chapter 01: The Manifesto & Asymmetric Editorial */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start mb-28">
        <div className="lg:col-span-5 space-y-6">
          <span className="text-[11px] font-mono-spec tracking-widest text-[#FF5A00] uppercase block font-bold">
            ARCHIVAL PROTOCOL // CHAPTER 01
          </span>
          <h3 className="font-ariovex text-3xl sm:text-4xl font-bold tracking-tight text-[#EAE7DE] leading-tight">
            THE ANATOMY OF SECONDARY SPEED
          </h3>
          <p className="font-apoc text-xl text-[#EAE7DE]/80 leading-relaxed">
            Mainstream cycling retail operates on planned seasonal obsolescence. REMAINDER operates on metallurgical permanence and structural provenance.
          </p>
          <div className="p-6 rounded-xl bg-white/5 border border-white/10 space-y-2">
            <h4 className="font-mono-spec text-xs uppercase font-bold text-[#EAE7DE]">
              The De-Stocking Filter
            </h4>
            <p className="text-xs text-[#EAE7DE]/70 leading-relaxed font-mono-spec">
              Fewer than 6% of components evaluated by our atelier meet the criteria for archival re-listing. We reject refinished counterfeits, micro-fractured prepreg carbon, and compromised clamp interfaces.
            </p>
          </div>
        </div>

        <div className="lg:col-span-7 space-y-8">
          {/* Editorial Plate 1: Ultrasonic Auditing */}
          <div className="p-8 rounded-2xl bg-white/40 border border-white/80 liquid-surface hover:shadow-xl transition-shadow duration-500">
            <div className="flex items-center justify-between text-xs font-mono-spec text-[#171717]/60 mb-4">
              <span className="text-[#FF5A00] font-bold">01.1 AUDIT METHODOLOGY</span>
              <span>FREQUENCY: 5.0 MHz SCAN</span>
            </div>
            <h4 className="font-apoc text-2xl font-semibold text-[#171717] mb-2">
              Non-Destructive Ultrasonic Tomography
            </h4>
            <p className="text-sm text-[#171717]/80 leading-relaxed font-apoc text-lg">
              Carbon fiber does not show fatigue visually until catastrophic shear occurs. Before any bar, wheel rim, or crankarm is accepted into our catalog, our engineers sweep the composite matrix with high-frequency ultrasound. Internal resin voids and delaminations are isolated and eliminated.
            </p>
          </div>

          {/* Editorial Plate 2: Metallurgical Integrity */}
          <div className="p-8 rounded-2xl bg-[#171717] text-[#EAE7DE] liquid-surface-dark hover:border-[#FF5A00]/40 transition-colors duration-500">
            <div className="flex items-center justify-between text-xs font-mono-spec text-white/50 mb-4">
              <span className="text-[#FF5A00] font-bold">01.2 METALLURGY</span>
              <span>ALLOY: 7075-T6 & TI-6AL-4V</span>
            </div>
            <h4 className="font-apoc text-2xl font-semibold text-[#EAE7DE] mb-2">
              Forged Billet & Grade 5 Titanium Hardware
            </h4>
            <p className="text-sm text-[#EAE7DE]/80 leading-relaxed font-apoc text-lg">
              All stem clamps, derailleur pivot bolts, and rotor spiders are inspected with digital micrometer calipers to confirm zero thread-pitch elongation. Original hardware is replaced with laser-marked aerospace grade 5 titanium Torx fasteners.
            </p>
          </div>
        </div>
      </div>

      {/* Chapter 02: Visual Restraint Break */}
      <div className="relative rounded-2xl overflow-hidden p-10 sm:p-14 bg-gradient-to-r from-[#171717] via-[#202022] to-[#171717] text-[#EAE7DE] border border-white/10 liquid-surface-dark">
        <div className="max-w-2xl space-y-4">
          <span className="text-[10px] font-mono-spec uppercase tracking-widest text-[#FF5A00]">
            CURATORIAL CONSTITUTION
          </span>
          <h3 className="font-ariovex text-2xl sm:text-3xl font-bold tracking-tight text-[#EAE7DE]">
            NO COUNTERFEITS. NO REPLICAS. ZERO COMPROMISE.
          </h3>
          <p className="font-apoc text-lg text-white/75 leading-relaxed">
            Every component ships with an NFC-embedded tamper-evident tamper seal, physical weight certificate verified to ±0.1g, and archival presentation sleeve.
          </p>
        </div>
      </div>
    </section>
  );
};

export default EditorialSection;
