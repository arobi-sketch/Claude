import React, { useState } from 'react';
import { X, Trash2, ArrowRight, ShieldCheck, Scale, CheckCircle2 } from 'lucide-react';
import { Product } from '../data/products';

export interface CartItem {
  product: Product;
  quantity: number;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [orderConfirmed, setOrderConfirmed] = useState(false);

  if (!isOpen) return null;

  const subtotalBDT = items.reduce((acc, item) => acc + item.product.priceBDT * item.quantity, 0);
  const totalWeight = items.reduce((acc, item) => acc + item.product.weightGrams * item.quantity, 0);
  const shippingBDT = subtotalBDT > 50000 ? 0 : 1500;
  const totalBDT = subtotalBDT + shippingBDT;

  const handleCheckout = () => {
    setIsCheckingOut(true);
    setTimeout(() => {
      setIsCheckingOut(false);
      setOrderConfirmed(true);
      onClearCart();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Liquid Backdrop */}
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/*
        Clipping layer for the sliding panel. Without this, the fixed-position
        panel below is measured against the viewport rather than this drawer's
        own box, and on mobile that let it render a sliver wider than the
        screen — the "slides a little right" drift after opening the drawer.
      */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="fixed inset-y-0 right-0 max-w-full flex">
          {/* w-full (not w-screen/100vw) keeps the panel from ever exceeding
              the actual viewport width on mobile browsers. */}
          <div className="w-full max-w-md bg-[#171717] text-[#EAE7DE] border-l border-white/15 shadow-2xl flex flex-col">
          {/* Header */}
          <div className="p-6 border-b border-white/10 flex items-center justify-between bg-white/5 backdrop-blur-md">
            <div className="flex items-center gap-3">
              <span className="font-ariovex text-sm font-bold text-white tracking-widest">
                ACQUISITIONS
              </span>
              <span className="px-2 py-0.5 rounded-full bg-[#FF5A00] text-white text-[11px] font-mono-spec font-bold">
                {items.reduce((acc, i) => acc + i.quantity, 0)}
              </span>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg hover:bg-white/10 transition-colors text-white cursor-pointer"
              aria-label="Close acquisitions drawer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {orderConfirmed ? (
              <div className="py-16 text-center space-y-4">
                <div className="w-14 h-14 rounded-full bg-[#FF5A00]/20 text-[#FF5A00] flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="font-apoc text-2xl font-semibold text-white">
                  Acquisition Dispatched
                </h3>
                <p className="text-xs text-white/70 max-w-xs mx-auto leading-relaxed font-mono-spec">
                  Dossier #REM-CHIT-4208 logged. Inspected components routed for climate-controlled courier packaging at Sagarika Branch, 4208, Chittagong.
                </p>
                <button
                  onClick={() => {
                    setOrderConfirmed(false);
                    onClose();
                  }}
                  className="mt-4 px-6 py-2.5 rounded-lg bg-[#FF5A00] text-white text-xs font-mono-spec uppercase tracking-wider hover:bg-white hover:text-[#171717] transition-colors cursor-pointer font-bold"
                >
                  Return to Archive
                </button>
              </div>
            ) : items.length === 0 ? (
              <div className="py-20 text-center space-y-4">
                <p className="font-apoc text-xl text-white/50 italic">
                  Your acquisition tray is empty.
                </p>
                <p className="text-xs text-white/60 max-w-xs mx-auto font-mono-spec">
                  Select certified specimens from our 8 component divisions.
                </p>
                <button
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-lg border border-[#FF5A00] text-[#FF5A00] hover:bg-[#FF5A00] hover:text-white text-xs font-mono-spec uppercase tracking-wider transition-colors cursor-pointer font-bold"
                >
                  Explore Component Register
                </button>
              </div>
            ) : (
              <>
                {/* Cart Items */}
                <div className="space-y-3">
                  {items.map(({ product, quantity }) => (
                    <div
                      key={product.id}
                      className="p-3.5 rounded-xl bg-white/5 border border-white/10 flex gap-3.5 relative"
                    >
                      <img
                        src={product.imageSrc}
                        alt={product.name}
                        className="w-16 h-16 rounded-lg object-cover bg-black/40 border border-white/10 shrink-0"
                      />

                      <div className="flex-1 min-w-0 pr-6">
                        <span className="text-[10px] font-mono-spec uppercase text-white/50 block truncate">
                          {product.brand} · {product.sectionLabel}
                        </span>
                        <h4 className="text-xs font-semibold text-white truncate">
                          {product.name}
                        </h4>
                        <div className="flex items-center gap-2 mt-1 text-[11px] font-mono-spec">
                          <span className="font-bold text-[#FF5A00]">
                            ৳{product.priceBDT.toLocaleString()} BDT
                          </span>
                          <span className="text-white/30">·</span>
                          <span className="text-white/60">{product.weightGrams}g</span>
                        </div>

                        {/* Quantity controls */}
                        <div className="flex items-center gap-2 mt-2">
                          <button
                            onClick={() => onUpdateQuantity(product.id, quantity - 1)}
                            className="w-5 h-5 rounded bg-white/10 flex items-center justify-center text-xs hover:bg-white/20 text-white cursor-pointer"
                          >
                            -
                          </button>
                          <span className="text-xs font-mono-spec px-1.5 text-white">{quantity}</span>
                          <button
                            onClick={() => onUpdateQuantity(product.id, quantity + 1)}
                            className="w-5 h-5 rounded bg-white/10 flex items-center justify-center text-xs hover:bg-white/20 text-white cursor-pointer"
                          >
                            +
                          </button>
                        </div>
                      </div>

                      <button
                        onClick={() => onRemoveItem(product.id)}
                        className="absolute top-3.5 right-3.5 text-white/40 hover:text-[#FF5A00] transition-colors p-1 cursor-pointer"
                        title="Remove specimen"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                {/* Build Metrics Aggregate */}
                <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-1.5 text-xs font-mono-spec">
                  <div className="flex items-center justify-between text-white/70">
                    <span className="flex items-center gap-1.5">
                      <Scale className="w-3.5 h-3.5 text-[#FF5A00]" />
                      Total Specimen Weight:
                    </span>
                    <span className="font-bold text-white">{totalWeight}g</span>
                  </div>
                  <div className="flex items-center justify-between text-white/70">
                    <span>Dispatch Origin:</span>
                    <span className="text-[#FF5A00] font-medium">Sagarika Branch (Chittagong)</span>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Footer / Summary */}
          {items.length > 0 && !orderConfirmed && (
            <div className="p-6 border-t border-white/10 bg-white/5 backdrop-blur-md space-y-4">
              <div className="space-y-1.5 text-xs font-mono-spec">
                <div className="flex justify-between text-white/70">
                  <span>Subtotal</span>
                  <span className="font-bold text-white">৳{subtotalBDT.toLocaleString()} BDT</span>
                </div>
                <div className="flex justify-between text-white/70">
                  <span>Courier Dispatch</span>
                  <span>{shippingBDT === 0 ? 'Complimentary (Above ৳50,000)' : `৳${shippingBDT} BDT`}</span>
                </div>
                <div className="pt-2 border-t border-white/10 flex justify-between text-sm font-bold text-white">
                  <span>Total Valuation</span>
                  <span className="text-base text-[#FF5A00]">৳{totalBDT.toLocaleString()} BDT</span>
                </div>
              </div>

              <button
                onClick={handleCheckout}
                disabled={isCheckingOut}
                className="w-full py-3.5 rounded-xl bg-[#FF5A00] text-white hover:bg-white hover:text-[#171717] font-medium text-xs font-mono-spec tracking-wider transition-all duration-300 flex items-center justify-center gap-2 shadow-lg cursor-pointer disabled:opacity-50"
              >
                {isCheckingOut ? (
                  <span>AUTHORIZING SAGARIKA DISPATCH...</span>
                ) : (
                  <>
                    <span>CONFIRM ACQUISITION IN BDT</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              <div className="flex items-center justify-center gap-2 text-[10px] font-mono-spec text-white/50 text-center">
                <ShieldCheck className="w-3.5 h-3.5 text-[#FF5A00]" />
                <span>Chittagong Certified · Direct Inspection Clearance</span>
              </div>
            </div>
          )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartDrawer;
