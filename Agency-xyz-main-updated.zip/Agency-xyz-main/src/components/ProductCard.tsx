import React, { useState } from 'react';
import { ArrowUpRight, Scale, Plus, Check, Shield } from 'lucide-react';
import { Product } from '../data/products';

interface ProductCardProps {
  product: Product;
  onInspect: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  isFeatured?: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onInspect,
  onAddToCart,
  isFeatured = false,
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [addedRecently, setAddedRecently] = useState(false);
  const [imageError, setImageError] = useState(false);

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product);
    setAddedRecently(true);
    setTimeout(() => setAddedRecently(false), 1200);
  };

  return (
    <div
      onClick={() => onInspect(product)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={`group relative rounded-2xl p-5 sm:p-6 transition-all duration-500 cursor-pointer bg-[#171717] text-[#EAE7DE] border border-white/15 hover:border-[#FF5A00] flex flex-col justify-between ${
        isFeatured ? 'shadow-2xl ring-1 ring-[#FF5A00]/30' : 'hover:shadow-xl'
      }`}
    >
      {/* Top Metadata Line */}
      <div className="flex items-center justify-between text-xs font-mono-spec text-white/60 mb-3.5">
        <div className="flex items-center gap-2 truncate">
          <span className="uppercase text-white/90 font-bold">{product.brand}</span>
          <span aria-hidden="true" className="text-white/30">/</span>
          <span className="text-[#FF5A00] font-medium">{product.batch}</span>
        </div>
        <div className="flex items-center gap-1.5 shrink-0 text-white/90">
          <Scale className="w-3.5 h-3.5 text-[#FF5A00]" />
          <span className="font-bold">{product.weightGrams}g</span>
        </div>
      </div>

      {/* Main Specimen Visual Slot: Real High Resolution Photo with Price Tag Printed On It */}
      <div className="relative aspect-[4/3] w-full rounded-xl overflow-hidden bg-[#0d0d0f] flex items-center justify-center mb-4 border border-white/10">
        {!imageError ? (
          <img
            src={product.imageSrc}
            alt={product.name}
            onError={() => setImageError(true)}
            className={`w-full h-full object-cover transition-transform duration-700 ${
              isHovered ? 'scale-105' : 'scale-100'
            }`}
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-[#202024] to-[#121214]">
            <Shield className="w-8 h-8 text-[#FF5A00] mb-2" />
            <span className="font-mono-spec text-xs font-bold text-white">{product.name}</span>
          </div>
        )}

        {/* Ambient Charcoal Gradient Scrim */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#171717] via-transparent to-black/30 pointer-events-none" />

        {/* Price Tag Printed Directly on Photo as requested */}
        <div className="absolute top-3 left-3 bg-[#171717]/90 backdrop-blur-md px-3 py-1 rounded-md border border-white/20 text-xs font-mono-spec font-bold text-[#FF5A00] shadow-lg">
          ৳{product.priceBDT.toLocaleString()} BDT
        </div>

        {/* Condition Badge */}
        <div className="absolute bottom-2.5 left-3 text-[10px] font-mono-spec uppercase text-white/70 tracking-wider">
          {product.condition}
        </div>

        {/* Quick Add Button */}
        <button
          onClick={handleQuickAdd}
          className={`absolute bottom-2.5 right-2.5 p-2 rounded-lg transition-all duration-300 shadow-md cursor-pointer flex items-center gap-1 ${
            addedRecently
              ? 'bg-[#FF5A00] text-white'
              : 'bg-white/15 text-white hover:bg-[#FF5A00] backdrop-blur-md border border-white/20'
          }`}
          title="Add to Acquisition Tray"
          aria-label={`Add ${product.name} to acquisition tray`}
        >
          {addedRecently ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
        </button>
      </div>

      {/* Title and Summary */}
      <div className="space-y-2 mb-4">
        <div className="flex flex-wrap gap-1.5 mb-1">
          {product.disciplines.map((disc) => (
            <span
              key={disc}
              className="text-[9px] font-mono-spec px-1.5 py-0.5 rounded bg-white/10 text-white/70"
            >
              {disc}
            </span>
          ))}
        </div>

        <h3 className="font-apoc text-xl font-semibold text-white leading-snug group-hover:text-[#FF5A00] transition-colors line-clamp-2">
          {product.name}
        </h3>
        <p className="text-xs text-white/60 line-clamp-2 leading-relaxed">
          {product.summary}
        </p>
      </div>

      {/* Bottom Valuation & Inspection Action */}
      <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs font-mono-spec">
        <div>
          <span className="text-[10px] text-white/40 uppercase block">Atelier Valuation</span>
          <span className="text-lg font-bold text-white">
            ৳{product.priceBDT.toLocaleString()}
          </span>
        </div>

        <span className="inline-flex items-center gap-1 text-white/60 group-hover:text-[#FF5A00] transition-colors uppercase tracking-wider font-semibold">
          <span>INSPECT</span>
          <ArrowUpRight className="w-3.5 h-3.5" />
        </span>
      </div>
    </div>
  );
};

export default ProductCard;
