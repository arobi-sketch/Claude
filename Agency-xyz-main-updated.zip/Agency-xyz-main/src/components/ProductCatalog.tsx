import React, { useState, useMemo } from 'react';
import { Search, GitFork, Disc, Cog, Layers, CircleDashed, Link2, Armchair, Wrench } from 'lucide-react';
import { Product, PRODUCTS, SECTIONS, RidingDiscipline } from '../data/products';
import { ProductCard } from './ProductCard';

// Visual reference icon + label for each of the 8 component divisions
const DIVISION_VISUALS: { id: string; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'forks', label: 'Forks', icon: GitFork },
  { id: 'brakes', label: 'Brakes', icon: Disc },
  { id: 'drivetrain', label: 'Drivetrain', icon: Cog },
  { id: 'cranksets', label: 'Cranksets', icon: Layers },
  { id: 'wheels', label: 'Wheels & Hubs', icon: CircleDashed },
  { id: 'cassettes', label: 'Cassettes', icon: Link2 },
  { id: 'saddles', label: 'Saddles', icon: Armchair },
  { id: 'tools', label: 'Tools & Accessories', icon: Wrench },
];

interface ProductCatalogProps {
  onInspectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  activeDiscipline: RidingDiscipline | 'ALL';
}

export const ProductCatalog: React.FC<ProductCatalogProps> = ({
  onInspectProduct,
  onAddToCart,
  searchQuery,
  onSearchChange,
  activeDiscipline,
}) => {
  const [activeSection, setActiveSection] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'weight-asc' | 'price-desc' | 'price-asc'>('weight-asc');

  // Filter products by discipline, section, and search query
  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((item) => {
      const matchesDiscipline =
        activeDiscipline === 'ALL' || item.disciplines.includes(activeDiscipline);
      const matchesSection =
        activeSection === 'all' || item.section === activeSection;
      const matchesSearch =
        searchQuery === '' ||
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.sectionLabel.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.material.toLowerCase().includes(searchQuery.toLowerCase());

      return matchesDiscipline && matchesSection && matchesSearch;
    }).sort((a, b) => {
      if (sortBy === 'weight-asc') return a.weightGrams - b.weightGrams;
      if (sortBy === 'price-desc') return b.priceBDT - a.priceBDT;
      if (sortBy === 'price-asc') return a.priceBDT - b.priceBDT;
      return 0;
    });
  }, [activeDiscipline, activeSection, searchQuery, sortBy]);

  // Group by sections when viewing 'all'
  const sectionsList = [
    { id: 'forks', title: '01. FORKS & SUSPENSION' },
    { id: 'brakes', title: '02. HYDRAULIC BRAKES & ROTORS' },
    { id: 'drivetrain', title: '03. GEARS & ELECTRONIC DRIVETRAIN' },
    { id: 'cranksets', title: '04. CRANKSETS & SPINDLES' },
    { id: 'wheels', title: '05. CARBON WHEELS & PRECISION HUBS' },
    { id: 'cassettes', title: '06. CHAINS & CASSETTES' },
    { id: 'saddles', title: '07. SADDLES & CONTACT' },
    { id: 'tools', title: '08. TOOLS & ACCESSORIES' },
  ];

  return (
    <div id="archive" className="space-y-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Catalog Header & Filters Bar */}
      <div className="p-6 sm:p-8 rounded-2xl bg-[#171717] text-[#EAE7DE] border border-white/15 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-white/10 mb-6">
          <div>
            <span className="text-[10px] font-mono-spec tracking-widest text-[#FF5A00] uppercase block mb-1 font-bold">
              CURATED SPECIMEN REGISTER
            </span>
            <h2 className="font-ariovex text-2xl sm:text-3xl font-bold tracking-tight text-white">
              8 CORE COMPONENT DIVISIONS
            </h2>
          </div>
          <div className="flex items-center gap-3 font-mono-spec text-xs text-white/60">
            <span>SHOWING {filteredProducts.length} SPECIMENS</span>
            <span>·</span>
            <span className="text-[#FF5A00] font-bold">CURRENCY: BDT (৳)</span>
          </div>
        </div>

        {/* Visual Reference: All 8 Component Divisions at a Glance */}
        <div className="mb-6">
          <span className="block mb-3 text-[10px] font-mono-spec uppercase tracking-widest text-white/50">
            Tap a division to filter
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {DIVISION_VISUALS.map((div) => {
              const Icon = div.icon;
              const isActive = activeSection === div.id;
              return (
                <button
                  key={div.id}
                  type="button"
                  onClick={() => setActiveSection(isActive ? 'all' : div.id)}
                  className={`flex flex-col items-center justify-center gap-2 aspect-square rounded-xl border p-3 transition-all cursor-pointer ${
                    isActive
                      ? 'bg-[#FF5A00] border-[#FF5A00] text-white shadow-lg'
                      : 'bg-white/5 border-white/10 text-white/80 hover:border-[#FF5A00]/60 hover:bg-white/10'
                  }`}
                >
                  <Icon className={`w-6 h-6 sm:w-7 sm:h-7 ${isActive ? 'text-white' : 'text-[#FF5A00]'}`} />
                  <span className="text-[9px] sm:text-[10px] font-mono-spec uppercase tracking-wider text-center leading-tight">
                    {div.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Section Navigation Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-3 scrollbar-none mb-6">
          {SECTIONS.map((sec) => (
            <button
              key={sec.id}
              onClick={() => setActiveSection(sec.id)}
              className={`px-3.5 py-2 rounded-lg text-xs font-mono-spec uppercase tracking-wider transition-all whitespace-nowrap cursor-pointer ${
                activeSection === sec.id
                  ? 'bg-[#FF5A00] text-white font-bold shadow-md'
                  : 'bg-white/5 text-white/70 hover:bg-white/10 hover:text-white border border-white/5'
              }`}
            >
              {sec.label}
            </button>
          ))}
        </div>

        {/* Search & Sort Controls */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-white/10">
          <div className="relative w-full sm:w-80">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-white/40 pointer-events-none" />
            <input
              type="text"
              placeholder="Search forks, brakes, XTR, Dura-Ace..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-lg bg-white/10 border border-white/20 text-xs font-mono-spec text-white placeholder-white/40 focus:outline-none focus:border-[#FF5A00]"
            />
          </div>

          <div className="w-full sm:w-auto">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
              className="w-full sm:w-auto px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-xs font-mono-spec text-white focus:outline-none focus:border-[#FF5A00] cursor-pointer"
            >
              <option value="weight-asc" className="bg-[#171717] text-white">Sort: Weight (Ultralight first)</option>
              <option value="price-desc" className="bg-[#171717] text-white">Sort: Valuation (High to Low)</option>
              <option value="price-asc" className="bg-[#171717] text-white">Sort: Valuation (Low to High)</option>
            </select>
          </div>
        </div>
      </div>

      {/* When filtering by a single section or search active */}
      {activeSection !== 'all' || searchQuery !== '' ? (
        <div>
          {filteredProducts.length === 0 ? (
            <div className="py-24 text-center rounded-2xl bg-[#171717] text-[#EAE7DE] border border-white/10 space-y-3">
              <p className="font-apoc text-2xl text-white/50 italic">
                No matching specimens found for {activeDiscipline !== 'ALL' ? activeDiscipline : 'your search'}.
              </p>
              <p className="text-xs font-mono-spec text-white/60">
                Try switching the discipline filter or clearing your query.
              </p>
              <button
                onClick={() => {
                  setActiveSection('all');
                  onSearchChange('');
                }}
                className="mt-4 px-4 py-2 rounded-lg border border-[#FF5A00] text-[#FF5A00] text-xs font-mono-spec uppercase tracking-wider hover:bg-[#FF5A00] hover:text-white transition-colors cursor-pointer"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="flex gap-6 overflow-x-auto pb-4 snap-x snap-mandatory scrollbar-none -mx-4 px-4 sm:mx-0 sm:px-0">
              {filteredProducts.map((prod) => (
                <div key={prod.id} className="shrink-0 w-[280px] sm:w-[320px] snap-start">
                  <ProductCard
                    product={prod}
                    onInspect={onInspectProduct}
                    onAddToCart={onAddToCart}
                  />
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        /* When viewing ALL: Render all 8 distinct sections with individual headers.
           Each division's specimens scroll horizontally rather than stacking into
           extra rows, so a section only ever grows sideways, never downward. */
        <div className="space-y-24">
          {sectionsList.map((sec) => {
            const sectionItems = filteredProducts.filter((p) => p.section === sec.id);
            if (sectionItems.length === 0) return null;

            return (
              <section key={sec.id} className="space-y-8">
                <div className="flex items-center justify-between pb-4 border-b border-white/15">
                  <div className="flex items-center gap-3">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#FF5A00]" />
                    <h3 className="font-ariovex text-xl sm:text-2xl font-bold tracking-tight text-[#EAE7DE]">
                      {sec.title}
                    </h3>
                  </div>
                  <span className="font-mono-spec text-xs text-[#EAE7DE]/70">
                    {sectionItems.length} SPECIMENS
                  </span>
                </div>

                <div className="flex gap-6 overflow-x-auto pb-4 snap-x snap-mandatory scrollbar-none -mx-4 px-4 sm:mx-0 sm:px-0">
                  {sectionItems.map((prod) => (
                    <div key={prod.id} className="shrink-0 w-[280px] sm:w-[320px] snap-start">
                      <ProductCard
                        product={prod}
                        onInspect={onInspectProduct}
                        onAddToCart={onAddToCart}
                      />
                    </div>
                  ))}
                </div>
              </section>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default ProductCatalog;
