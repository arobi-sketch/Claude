import React from 'react';
import { RidingDiscipline, DISCIPLINES } from '../data/products';
import { Compass, Check } from 'lucide-react';

interface RiderQuestionnaireProps {
  activeDiscipline: RidingDiscipline | 'ALL';
  onSelectDiscipline: (discipline: RidingDiscipline | 'ALL') => void;
  itemCounts: Record<string, number>;
}

export const RiderQuestionnaire: React.FC<RiderQuestionnaireProps> = ({
  activeDiscipline,
  onSelectDiscipline,
  itemCounts,
}) => {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-12">
      <div className="p-6 sm:p-8 rounded-2xl bg-[#171717] text-[#EAE7DE] border border-white/15 shadow-2xl relative overflow-hidden">
        {/* Background Subtle Gradient Glow */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#FF5A00]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6 pb-4 border-b border-white/10">
          <div>
            <div className="inline-flex items-center gap-2 text-[10px] font-mono-spec tracking-widest text-[#FF5A00] uppercase font-bold mb-1">
              <Compass className="w-3.5 h-3.5" />
              <span>DISCIPLINE CALIBRATION</span>
            </div>
            <h3 className="font-ariovex text-xl sm:text-2xl font-bold tracking-tight text-white">
              WHAT DO YOU RIDE?
            </h3>
          </div>
          <p className="font-apoc text-sm sm:text-base text-white/70 max-w-md leading-relaxed">
            Select your primary machine geometry to calibrate our archival catalog to your exact cockpit, gear ratios, and axle standards.
          </p>
        </div>

        {/* Discipline Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5">
          {DISCIPLINES.map((d) => {
            const isSelected = activeDiscipline === d.id;
            const count = itemCounts[d.id] ?? 0;

            return (
              <button
                key={d.id}
                onClick={() => onSelectDiscipline(d.id)}
                className={`p-3 rounded-xl border text-left transition-all duration-300 flex flex-col justify-between cursor-pointer group relative ${
                  isSelected
                    ? 'bg-[#FF5A00] text-white border-[#FF5A00] shadow-lg scale-[1.02]'
                    : 'bg-white/5 border-white/10 text-white/80 hover:bg-white/10 hover:border-white/20'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <span className={`font-mono-spec text-xs font-bold tracking-wider uppercase ${isSelected ? 'text-white' : 'text-white/90'}`}>
                    {d.label}
                  </span>
                  {isSelected ? (
                    <Check className="w-3.5 h-3.5 text-white shrink-0" />
                  ) : (
                    <span className="text-[10px] font-mono-spec text-white/40 group-hover:text-[#FF5A00]">
                      {count}
                    </span>
                  )}
                </div>

                <p className={`text-[10px] line-clamp-1 ${isSelected ? 'text-white/90 font-medium' : 'text-white/50'}`}>
                  {d.desc}
                </p>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default RiderQuestionnaire;
