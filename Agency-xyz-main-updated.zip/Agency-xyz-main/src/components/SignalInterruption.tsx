import React, { useState } from 'react';
import { Calculator, ArrowUpRight, CheckCircle, MessageSquare, Mail, Phone } from 'lucide-react';

export const SignalInterruption: React.FC = () => {
  const [componentType, setComponentType] = useState<string>('fork');
  const [condition, setCondition] = useState<string>('mint');
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [contactInput, setContactInput] = useState<string>('');

  // Valuation matrix in BDT
  const valuationsBDT: Record<string, number> = {
    fork: 95000,
    brakes: 42000,
    drivetrain: 58000,
    crankset: 68000,
    wheels: 165000,
    cassettes: 28000,
    saddles: 24000,
    tools: 12000,
  };

  const conditionMultiplier: Record<string, number> = {
    boxed: 1.25,
    mint: 1.0,
    ridden: 0.78,
  };

  const basePrice = valuationsBDT[componentType] || 45000;
  const multiplier = conditionMultiplier[condition] || 1.0;
  const estimatedPayoutBDT = Math.round(basePrice * multiplier);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactInput) return;
    setSubmitted(true);
  };

  return (
    <section id="acquisition" className="relative py-20 sm:py-32 px-4 sm:px-6 lg:px-8 overflow-hidden bg-[#FF5A00] text-[#171717] w-full">
      {/* Background Refraction Overlays */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.18)_0%,transparent_70%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-16 items-center w-full">
          {/* Left Column: Bold Manifesto */}
          <div className="lg:col-span-7 space-y-5 sm:space-y-6 w-full">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-[#171717] text-[#EAE7DE] text-[10px] sm:text-[11px] font-mono-spec tracking-wider sm:tracking-widest uppercase max-w-full">
              <span className="w-2 h-2 rounded-full bg-[#FF5A00] shrink-0" />
              <span className="truncate">THE RE-ACQUISITION PROTOCOL // CHITTAGONG</span>
            </div>

            <h2 className="font-ariovex text-2xl sm:text-4xl md:text-5xl lg:text-6xl font-black tracking-tight text-[#171717] leading-[1.08] break-words">
              WE APPRAISE. <br />
              WE CERTIFY. <br />
              WE RE-CIRCULATE.
            </h2>

            <p className="font-apoc text-lg sm:text-2xl text-[#171717]/90 leading-relaxed max-w-xl">
              Do not let elite carbon or forged components sit idle in workshop drawers. REMAINDER purchases and consignes authentic bicycle parts directly through our Sagarika branch in Chittagong.
            </p>

            {/* Direct Contact Anchors */}
            <div className="pt-4 border-t border-[#171717]/20 flex flex-col sm:flex-row flex-wrap gap-3 font-mono-spec text-xs w-full">
              <a
                href="https://wa.me/8801976912749"
                target="_blank"
                rel="noreferrer"
                className="px-4 py-2.5 rounded-xl bg-[#171717] text-[#EAE7DE] hover:bg-white hover:text-[#171717] transition-colors flex items-center justify-center sm:justify-start gap-2 font-bold cursor-pointer"
              >
                <Phone className="w-3.5 h-3.5 text-[#FF5A00] shrink-0" />
                <span>WHATSAPP: 01976912749</span>
              </a>

              <a
                href="mailto:sifat.01938168@gmail.com"
                className="px-4 py-2.5 rounded-xl bg-white/20 text-[#171717] hover:bg-[#171717] hover:text-white transition-colors flex items-center justify-center sm:justify-start gap-2 font-bold cursor-pointer max-w-full"
              >
                <Mail className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">SIFAT.01938168@GMAIL.COM</span>
              </a>
            </div>
          </div>

          {/* Right Column: Instant Residual Valuation in BDT */}
          <div className="lg:col-span-5 w-full">
            <div className="rounded-2xl bg-[#171717] text-[#EAE7DE] p-5 sm:p-8 shadow-2xl border border-white/20 liquid-surface-dark relative w-full overflow-hidden">
              <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-6">
                <div className="flex items-center gap-2">
                  <Calculator className="w-4 h-4 text-[#FF5A00]" />
                  <span className="font-mono-spec text-xs uppercase tracking-widest text-white/90">
                    RESIDUAL APPRAISER (BDT)
                  </span>
                </div>
                <span className="text-[10px] font-mono-spec text-[#FF5A00] font-bold">
                  SAGARIKA BRANCH
                </span>
              </div>

              {submitted ? (
                <div className="py-8 text-center space-y-4">
                  <div className="w-12 h-12 rounded-full bg-[#FF5A00]/20 text-[#FF5A00] flex items-center justify-center mx-auto">
                    <CheckCircle className="w-6 h-6" />
                  </div>
                  <h4 className="font-apoc text-xl font-semibold text-[#EAE7DE]">
                    Appraisal Dossier Opened
                  </h4>
                  <p className="text-xs text-white/70 max-w-xs mx-auto leading-relaxed font-mono-spec">
                    Our Chittagong appraisal team has received your specimen request. You will be contacted via {contactInput} with courier collection instructions.
                  </p>
                  <button
                    onClick={() => setSubmitted(false)}
                    className="mt-2 text-xs font-mono-spec text-[#FF5A00] underline hover:text-white transition-colors cursor-pointer"
                  >
                    Evaluate Another Specimen
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4 text-xs font-mono-spec">
                  <div>
                    <label className="block text-white/60 mb-1.5 uppercase text-[10px]">
                      Component Category
                    </label>
                    <select
                      value={componentType}
                      onChange={(e) => setComponentType(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-lg bg-white/10 border border-white/20 text-white focus:outline-none focus:border-[#FF5A00] transition-colors cursor-pointer"
                    >
                      <option value="fork" className="bg-[#171717] text-white">Suspension / Carbon Fork</option>
                      <option value="brakes" className="bg-[#171717] text-white">Hydraulic Disc Brakeset</option>
                      <option value="drivetrain" className="bg-[#171717] text-white">Electronic Derailleur / Groupset</option>
                      <option value="crankset" className="bg-[#171717] text-white">Carbon / Billet Crankset</option>
                      <option value="wheels" className="bg-[#171717] text-white">Carbon Wheelset / Ceramic Hubs</option>
                      <option value="cassettes" className="bg-[#171717] text-white">Titanium Cassette & Chain</option>
                      <option value="saddles" className="bg-[#171717] text-white">3D Printed / Monocoque Saddle</option>
                      <option value="tools" className="bg-[#171717] text-white">Precision Tools & Workshop Accessories</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-white/60 mb-1.5 uppercase text-[10px]">
                      Condition Grading
                    </label>
                    <div className="grid grid-cols-3 gap-1.5 sm:gap-2">
                      {[
                        { id: 'boxed', label: 'Boxed NOS' },
                        { id: 'mint', label: 'Atelier Mint' },
                        { id: 'ridden', label: 'Grade A' },
                      ].map((c) => (
                        <button
                          key={c.id}
                          type="button"
                          onClick={() => setCondition(c.id)}
                          className={`py-2 px-1.5 sm:px-2 text-center rounded border transition-all cursor-pointer text-[10px] sm:text-xs truncate ${
                            condition === c.id
                              ? 'bg-[#FF5A00] text-white border-[#FF5A00] font-bold'
                              : 'bg-white/5 text-white/70 border-white/10 hover:border-white/30'
                          }`}
                        >
                          {c.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Valuation Display Box */}
                  <div className="pt-4 mt-2 border-t border-white/10 flex flex-wrap items-baseline justify-between gap-2">
                    <div>
                      <span className="text-[10px] uppercase text-white/50 block">
                        Estimated Buyout Value (BDT)
                      </span>
                      <span className="text-2xl sm:text-3xl font-bold text-[#FF5A00]">
                        ৳{estimatedPayoutBDT.toLocaleString()}
                      </span>
                    </div>
                    <span className="text-[10px] text-white/40">Direct Bank / bKash Payout</span>
                  </div>

                  {/* Submission Field */}
                  <div className="pt-2">
                    <label className="block text-white/60 mb-1.5 uppercase text-[10px]">
                      Your Mobile WhatsApp / Email
                    </label>
                    <div className="flex gap-2 w-full">
                      <input
                        type="text"
                        required
                        placeholder="01976912749 or email..."
                        value={contactInput}
                        onChange={(e) => setContactInput(e.target.value)}
                        className="flex-1 min-w-0 px-3 py-2.5 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/30 focus:outline-none focus:border-[#FF5A00] text-xs"
                      />
                      <button
                        type="submit"
                        className="px-4 py-2.5 rounded-lg bg-[#FF5A00] text-white font-bold hover:bg-white hover:text-[#171717] transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
                      >
                        <span>SEND</span>
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SignalInterruption;
