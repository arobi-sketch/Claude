import React from 'react';
import { Sparkles, Shield, Cpu, RefreshCw } from 'lucide-react';

export const ManifestoSection: React.FC = () => {
  return (
    <section className="py-20 sm:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-[#171717]">
      <div className="rounded-3xl bg-[#171717] text-[#EAE7DE] p-8 sm:p-14 lg:p-20 shadow-2xl border border-white/15 relative overflow-hidden">
        {/* Ambient Orange & Dark Smoke Lighting */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#FF5A00]/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-white/5 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-4xl mx-auto text-center space-y-8">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 border border-white/15 text-[11px] font-mono-spec tracking-[0.25em] text-[#FF5A00] uppercase font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>THE CURATORIAL MANIFESTO</span>
          </div>

          <h2 className="font-ariovex text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-black tracking-tight text-white leading-[1.04]">
            SAME CYCLE. <br />
            <span className="text-[#FF5A00]">HIGHER STANDARDS.</span>
          </h2>

          <p className="font-apoc text-xl sm:text-2xl md:text-3xl text-white/85 leading-relaxed max-w-3xl mx-auto">
            A bicycle does not reach its apex on the assembly line floor. True speed is distilled through metallurgical provenance, individual carbon acoustic tomography, and secondary perfection.
          </p>

          <p className="text-xs sm:text-sm font-mono-spec text-white/60 max-w-2xl mx-auto leading-relaxed uppercase tracking-wider">
            We decommission WorldTour test chassis, reclaim unopened team course reserve inventories, and verify each specimen within 0.05mm runout tolerances at our Sagarika workshop.
          </p>

          {/* Core Pillars */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-8 border-t border-white/10 text-left">
            <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-1.5">
              <span className="font-mono-spec text-[10px] text-[#FF5A00] uppercase block">
                Pillar 01
              </span>
              <h4 className="font-ariovex text-xs font-bold text-white uppercase">
                Carbon Tomography
              </h4>
              <p className="font-apoc text-xs text-white/70">
                5.0 MHz acoustic scan detecting internal resin voids and delaminations.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-1.5">
              <span className="font-mono-spec text-[10px] text-[#FF5A00] uppercase block">
                Pillar 02
              </span>
              <h4 className="font-ariovex text-xs font-bold text-white uppercase">
                Titanium Hardware
              </h4>
              <p className="font-apoc text-xs text-white/70">
                All pivot pins and faceplate bolts upgraded to laser-marked Grade 5 Ti.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-1.5">
              <span className="font-mono-spec text-[10px] text-[#FF5A00] uppercase block">
                Pillar 03
              </span>
              <h4 className="font-ariovex text-xs font-bold text-white uppercase">
                Residual Preservation
              </h4>
              <p className="font-apoc text-xs text-white/70">
                Guaranteed buyback valuation in BDT for certified specimens.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ManifestoSection;
