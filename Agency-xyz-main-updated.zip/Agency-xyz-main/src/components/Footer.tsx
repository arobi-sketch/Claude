import React, { useState } from 'react';
import { ArrowUpRight, CheckCircle2, Phone, Mail, MapPin } from 'lucide-react';
import { RemainderLogo } from './RemainderLogo';

export const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSubscribed(true);
    setEmail('');
  };

  return (
    <footer className="mt-32 border-t border-white/10 bg-[#171717] text-[#EAE7DE] pt-20 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-16">
        {/* Top Tier: Brand, Chittagong Coordinates & Direct Contract Options */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          <div className="lg:col-span-5 space-y-6">
            <div className="flex items-center gap-3">
              <RemainderLogo size={36} />
              <span className="font-ariovex text-lg font-bold tracking-[0.2em] text-[#EAE7DE]">
                REMAINDER
              </span>
            </div>

            <p className="font-apoc text-base sm:text-lg text-white/70 max-w-sm leading-relaxed">
              Cycle parts retailer and archival component reseller. Precision carbon, mechanical provenance, and atmospheric selection.
            </p>

            {/* Chittagong Branch Coordinates & Contacts */}
            <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-2.5 text-xs font-mono-spec">
              <div className="flex items-center gap-2 text-[#FF5A00] font-bold">
                <MapPin className="w-3.5 h-3.5 shrink-0" />
                <span>SAGARIKA BRANCH, 4208, CHITTAGONG</span>
              </div>

              <div className="flex items-center gap-2 text-white/80">
                <Phone className="w-3.5 h-3.5 text-[#FF5A00] shrink-0" />
                <span>WHATSAPP: </span>
                <a
                  href="https://wa.me/8801976912749"
                  target="_blank"
                  rel="noreferrer"
                  className="text-white hover:text-[#FF5A00] underline font-bold"
                >
                  01976912749
                </a>
              </div>

              <div className="flex items-center gap-2 text-white/80">
                <Mail className="w-3.5 h-3.5 text-[#FF5A00] shrink-0" />
                <span>MAIL: </span>
                <a
                  href="mailto:sifat.01938168@gmail.com"
                  className="text-white hover:text-[#FF5A00] underline"
                >
                  sifat.01938168@gmail.com
                </a>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 space-y-4">
            <span className="text-[10px] font-mono-spec uppercase tracking-widest text-[#FF5A00] block font-bold">
              ATELIER DISPATCH // CHITTAGONG SATELLITE
            </span>
            <p className="font-apoc text-xl text-[#EAE7DE] max-w-md">
              Receive private dispatch alerts 24 hours prior to public batch releases and rare de-stocking acquisitions in Bangladesh.
            </p>

            {subscribed ? (
              <div className="flex items-center gap-2 text-xs font-mono-spec text-[#FF5A00] bg-white/5 p-3 rounded-xl border border-white/10 max-w-md">
                <CheckCircle2 className="w-4 h-4" />
                <span>Registered for Chittagong private dispatch alerts.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex gap-2 max-w-md">
                <input
                  type="email"
                  required
                  placeholder="curator@atelier.cc"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="flex-1 px-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white placeholder-white/30 text-xs font-mono-spec focus:outline-none focus:border-[#FF5A00]"
                />
                <button
                  type="submit"
                  className="px-5 py-3 rounded-xl bg-[#FF5A00] text-white font-bold text-xs font-mono-spec hover:bg-white hover:text-[#171717] transition-all flex items-center gap-1 cursor-pointer shrink-0"
                >
                  <span>JOIN</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Links Navigation Matrix */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-8 pt-12 border-t border-white/10 text-xs font-mono-spec">
          <div className="space-y-3">
            <span className="text-white/40 uppercase tracking-wider block text-[10px]">
              8 Divisions
            </span>
            <ul className="space-y-2 text-white/80">
              <li><a href="#archive" className="hover:text-[#FF5A00] transition-colors">Forks & Suspension</a></li>
              <li><a href="#archive" className="hover:text-[#FF5A00] transition-colors">Hydraulic Brakes</a></li>
              <li><a href="#archive" className="hover:text-[#FF5A00] transition-colors">Gears & Drivetrain</a></li>
              <li><a href="#archive" className="hover:text-[#FF5A00] transition-colors">Cranksets & Spindles</a></li>
            </ul>
          </div>

          <div className="space-y-3">
            <span className="text-white/40 uppercase tracking-wider block text-[10px]">
              Components
            </span>
            <ul className="space-y-2 text-white/80">
              <li><a href="#archive" className="hover:text-[#FF5A00] transition-colors">Wheels & Hubs</a></li>
              <li><a href="#archive" className="hover:text-[#FF5A00] transition-colors">Chains & Cassettes</a></li>
              <li><a href="#archive" className="hover:text-[#FF5A00] transition-colors">Carbon Saddles</a></li>
              <li><a href="#archive" className="hover:text-[#FF5A00] transition-colors">Tools & Accessories</a></li>
              <li><a href="#archive" className="hover:text-[#FF5A00] transition-colors">Batch 04 Drop</a></li>
            </ul>
          </div>

          <div className="space-y-3">
            <span className="text-white/40 uppercase tracking-wider block text-[10px]">
              Direct Contract
            </span>
            <ul className="space-y-2 text-white/80">
              <li><a href="https://wa.me/8801976912749" target="_blank" rel="noreferrer" className="hover:text-[#FF5A00] transition-colors">WhatsApp 01976912749</a></li>
              <li><a href="mailto:sifat.01938168@gmail.com" className="hover:text-[#FF5A00] transition-colors">Email Curator</a></li>
              <li><a href="#acquisition" className="hover:text-[#FF5A00] transition-colors">Appraisal Request</a></li>
              <li><span className="text-white/40">Sagarika Branch 4208</span></li>
            </ul>
          </div>

          <div className="space-y-3">
            <span className="text-white/40 uppercase tracking-wider block text-[10px]">
              Settlement
            </span>
            <ul className="space-y-2 text-white/80">
              <li><span className="text-white/50">CURRENCY: BDT (৳)</span></li>
              <li><span className="text-white/50">DIRECT BANK / BKASH</span></li>
              <li><span className="text-white/50">ULTRASONIC CERTIFIED</span></li>
              <li><span className="text-white/50">ESCROW ASSURED</span></li>
            </ul>
          </div>
        </div>

        {/* Bottom Legal & Single-Line Copyright */}
        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] font-mono-spec text-white/40">
          <p>© 2026 REMAINDER. SAGARIKA BRANCH, 4208, CHITTAGONG. ALL RIGHTS RESERVED.</p>
          <div className="flex items-center gap-6">
            <span>CHARCOAL 45%</span>
            <span>·</span>
            <span>BONE 45%</span>
            <span>·</span>
            <span className="text-[#FF5A00]">SIGNAL ORANGE 10%</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
