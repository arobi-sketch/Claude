import React from 'react';
import { X, ShieldCheck, ArrowRight, Scale, Layers, Award } from 'lucide-react';
import { Product } from '../data/products';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  onClose,
  onAddToCart,
}) => {
  if (!product) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-10 overflow-y-auto">
      {/* Liquid Backdrop */}
      <div
        className="fixed inset-0 bg-[#171717]/85 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      {/* Modal Dialog (Rich Charcoal Atmosphere) */}
      <div className="relative w-full max-w-4xl bg-[#171717] text-[#EAE7DE] rounded-2xl overflow-hidden shadow-2xl border border-white/20 z-10 my-auto">
        {/* Header / Dismiss */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-white/5 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <span className="font-mono-spec text-[11px] text-[#FF5A00] tracking-widest uppercase font-bold">
              ATELIER INSPECTION DOSSIER
            </span>
            <span className="text-white/30">/</span>
            <span className="font-mono-spec text-xs text-white/60">
              SERIAL: {product.serialNumber}
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/10 transition-colors text-white cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Split: Real Photo & Technical Dossier */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-0">
          {/* Left Column: High-Res Specimen Photo */}
          <div className="md:col-span-6 p-6 sm:p-8 flex flex-col justify-between bg-black/40 border-b md:border-b-0 md:border-r border-white/10">
            <div className="relative aspect-square w-full rounded-xl overflow-hidden border border-white/15 bg-[#0d0d0f]">
              <img
                src={product.imageSrc}
                alt={product.name}
                className="w-full h-full object-cover"
              />

              {/* Price Tag Printed Directly on Photo */}
              <div className="absolute top-3 left-3 bg-[#171717]/90 backdrop-blur-md px-3 py-1 rounded-md border border-white/20 text-xs font-mono-spec font-bold text-[#FF5A00] shadow-lg">
                ৳{product.priceBDT.toLocaleString()} BDT
              </div>

              {/* Verified Weight Badge */}
              <div className="absolute bottom-3 right-3 bg-black/80 backdrop-blur-md px-3 py-1 rounded border border-white/15 text-xs font-mono-spec flex items-center gap-1.5 text-white">
                <Scale className="w-3.5 h-3.5 text-[#FF5A00]" />
                <span className="font-bold">{product.weightGrams}g</span>
                <span className="text-[10px] text-white/60">VERIFIED</span>
              </div>
            </div>

            {/* Provenance Checklist */}
            <div className="mt-6 p-4 rounded-xl bg-white/5 border border-white/10 space-y-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-[#FF5A00]">
                <ShieldCheck className="w-4 h-4" />
                <span>Sagarika Branch Certification</span>
              </div>
              <p className="text-xs text-white/70 leading-relaxed font-mono-spec">
                {product.provenance}
              </p>
            </div>
          </div>

          {/* Right Column: Technical Dossier & Acquisition */}
          <div className="md:col-span-6 p-6 sm:p-8 flex flex-col justify-between space-y-6">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs uppercase tracking-widest text-white/60 font-semibold font-mono-spec">
                  {product.brand}
                </span>
                <span className="inline-flex items-center gap-1 text-xs font-mono-spec text-[#FF5A00] bg-[#FF5A00]/15 px-2 py-0.5 rounded border border-[#FF5A00]/30">
                  <Award className="w-3 h-3" />
                  {product.condition}
                </span>
              </div>

              <h2 className="font-apoc text-2xl sm:text-3xl font-semibold leading-tight text-white mb-3">
                {product.name}
              </h2>

              <p className="text-sm text-white/80 leading-relaxed mb-6 font-apoc">
                {product.summary}
              </p>

              {/* Technical Specifications Grid */}
              <div className="mb-6">
                <h4 className="text-xs uppercase tracking-widest font-mono-spec text-white/50 mb-3">
                  Engineering Specifications
                </h4>
                <div className="grid grid-cols-2 gap-2 text-xs font-mono-spec">
                  {product.specs.map((s, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded bg-white/5 border border-white/10 flex flex-col"
                    >
                      <span className="text-[10px] text-white/50 uppercase">{s.label}</span>
                      <span className="font-semibold text-white mt-0.5">{s.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Composition */}
              <div className="flex items-center gap-2 text-xs font-mono-spec text-white/70">
                <Layers className="w-3.5 h-3.5 text-[#FF5A00]" />
                <span>Metallurgy: {product.material}</span>
              </div>
            </div>

            {/* Price & Primary Action */}
            <div className="pt-6 border-t border-white/10 flex items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-mono-spec text-white/50 uppercase block">
                  Atelier Valuation
                </span>
                <span className="font-mono-spec text-2xl font-bold text-[#FF5A00]">
                  ৳{product.priceBDT.toLocaleString()} BDT
                </span>
              </div>

              <button
                onClick={() => {
                  onAddToCart(product);
                  onClose();
                }}
                className="px-6 py-3.5 rounded-xl bg-[#FF5A00] text-white hover:bg-white hover:text-[#171717] font-medium text-xs font-mono-spec tracking-wider transition-all duration-300 flex items-center gap-2 shadow-lg cursor-pointer whitespace-nowrap"
              >
                <span>ACQUIRE SPECIMEN</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductModal;
